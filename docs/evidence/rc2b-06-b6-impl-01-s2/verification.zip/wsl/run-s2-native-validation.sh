#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 <canonical-gagamba-repo> <expected-commit>" >&2
  exit 2
fi
repo=$(realpath "$1")
expected_commit=$2
if [[ $(id -u) -eq 0 ]]; then echo 'refusing root execution' >&2; exit 1; fi
if [[ ${#expected_commit} -ne 40 || ! $expected_commit =~ ^[0-9a-f]{40}$ ]]; then
  echo 'expected commit must be 40 lowercase hex digits' >&2; exit 2
fi
git_safe() { git -c "safe.directory=$repo" -c core.fileMode=false -c core.autocrlf=true -C "$repo" "$@"; }
[[ $(git_safe symbolic-ref --quiet --short HEAD) == main ]] || { echo 'canonical branch is not main' >&2; exit 1; }
[[ $(git_safe rev-parse HEAD) == "$expected_commit" ]] || { echo 'canonical HEAD differs from requested commit' >&2; exit 1; }
[[ $(git_safe rev-parse "$expected_commit^{tree}") == $(git_safe rev-parse HEAD^{tree}) ]] || exit 1

validator_root=/mnt/c/Users/Laszlos/source/repos/Solo/.tmp/b6-s2-recovery-20261102/validation
result_dir="$validator_root/$expected_commit"
if [[ -e "$result_dir" ]]; then echo "refusing to overwrite evidence directory: $result_dir" >&2; exit 1; fi
mkdir -p "$result_dir"
cp "$validator_root/run-s2-native-validation.sh" "$result_dir/"
cp "$validator_root/probe-cli-mutations.py" "$result_dir/"
run_root="$(mktemp -d "/tmp/gagamba-s2-validation.${expected_commit}.XXXXXXXX")"
source_root="$run_root/source"
candidate_root="$run_root/candidate"
mkdir -p "$source_root"
cleanup() {
  status=$?
  trap - EXIT
  printf '%s\n' "$status" > "$result_dir/exit-code.txt"
  printf 'run_root=%s\nsource_root=%s\ncandidate_root=%s\n' "$run_root" "$source_root" "$candidate_root" > "$result_dir/paths.txt"
  # Keep the ext4 candidate and archived source available for independent inspection.
}
trap cleanup EXIT

printf 'uid=%s\n' "$(id -u)" > "$result_dir/environment.txt"
uname -smr >> "$result_dir/environment.txt"
cat /etc/os-release >> "$result_dir/environment.txt"
dotnet --info >> "$result_dir/environment.txt" 2>&1
gcc --version | head -1 >> "$result_dir/environment.txt"
python3 --version >> "$result_dir/environment.txt"
git_safe archive --format=tar "$expected_commit" > "$result_dir/source-archive.tar"
tar -xf "$result_dir/source-archive.tar" -C "$source_root"
sha256sum "$result_dir/source-archive.tar" > "$result_dir/source-archive.sha256"

bash "$source_root/eng/linux-m1/build-install-candidate.sh" "$repo" "$run_root/build-output" \
  2>&1 | tee "$result_dir/candidate-build.log"
candidate_root="$run_root/build-output/candidate"
[[ -f "$candidate_root/manifest.json" && -f "$run_root/build-output/artifact-set.sha256" ]]
cp "$candidate_root/manifest.json" "$result_dir/manifest.json"
cp "$run_root/build-output/artifact-set.sha256" "$result_dir/artifact-set.sha256"
tar -czf "$result_dir/candidate-payload.tar.gz" -C "$run_root/build-output" candidate
sha256sum "$result_dir/candidate-payload.tar.gz" > "$result_dir/candidate-payload.tar.gz.sha256"

(
  cd "$candidate_root"
  find . -type f -print0 | sort -z | xargs -0 sha256sum
) > "$result_dir/binary-inventory.sha256"
(
  cd "$candidate_root"
  python3 - <<'PY'
import json
from pathlib import Path
m = json.loads(Path('manifest.json').read_bytes())
for artifact in m['artifacts']:
    if artifact['path'].endswith('.deps.json'):
        print(f"{artifact['path']} sha256={artifact['sha256']}")
        d = json.loads(Path(artifact['path']).read_bytes())
        target = d['runtimeTarget']['name']
        print(f"  runtimeTarget={target}")
        for name, item in sorted(d['targets'][target].items()):
            print(f"  library={name} runtime={','.join(item.get('runtime', {}))} native={','.join(item.get('native', {}))} runtimeTargets={','.join(item.get('runtimeTargets', {}))}")
PY
) > "$result_dir/dependency-inventory.txt"

file "$candidate_root/native/exec-coordinator" > "$result_dir/native-binary.txt"
readelf -d "$candidate_root/native/exec-coordinator" >> "$result_dir/native-binary.txt" 2>&1 || true
sha256sum "$candidate_root/native/exec-coordinator" "$candidate_root/native/seccomp-filter.bin" >> "$result_dir/native-binary.txt"

dotnet run --project "$source_root/eng/InstallTool/InstallTool.csproj" -c Release \
  -p:NuGetAudit=false -- check-payload "$candidate_root" \
  2>&1 | tee "$result_dir/check-payload.log"

export GAGAMBA_S2_TEST_CANDIDATE="$candidate_root"
dotnet test "$source_root/tests/Gagamba.Execution.Linux.M1.Tests/Gagamba.Execution.Linux.M1.Tests.csproj" \
  -c Release -p:NuGetAudit=false --filter 'FullyQualifiedName~Gagamba.Execution.Linux.M1.Tests.Installation' \
  --logger "trx;LogFileName=installation-portable.trx" \
  2>&1 | tee "$result_dir/installation-portable-tests.log"
dotnet test "$source_root/tests/Gagamba.Execution.Linux.M1.Tests/Gagamba.Execution.Linux.M1.Tests.csproj" \
  -c Release -p:NuGetAudit=false --filter 'FullyQualifiedName~Gagamba.Execution.Linux.M1.Tests.Installed.InstalledFileSystemNativeTests' \
  --logger "trx;LogFileName=installed-filesystem-native.trx" \
  2>&1 | tee "$result_dir/installed-filesystem-native-tests.log"

python3 "$validator_root/probe-cli-mutations.py" "$candidate_root" "$source_root" "$result_dir" \
  2>&1 | tee "$result_dir/cli-mutation-probes.log"

cp "$source_root/tests/Gagamba.Execution.Linux.M1.Tests/TestResults/installation-portable.trx" "$result_dir/" 2>/dev/null || true
cp "$source_root/tests/Gagamba.Execution.Linux.M1.Tests/TestResults/installed-filesystem-native.trx" "$result_dir/" 2>/dev/null || true
printf 'PASS\n' > "$result_dir/result.txt"
{
  printf 'source.commit=%s\nsource.tree=%s\n' "$expected_commit" "$(git_safe rev-parse "$expected_commit^{tree}")"
  printf 'artifactSetSha256=%s\n' "$(cat "$run_root/build-output/artifact-set.sha256")"
  printf 'candidatePayload=%s\n' "$result_dir/candidate-payload.tar.gz"
  grep 'Passed!' "$result_dir/installation-portable-tests.log"
  grep 'Passed!' "$result_dir/installed-filesystem-native-tests.log"
  printf 'InstallTool check-payload and CLI mutation probes: PASS\n'
} > "$result_dir/summary.txt"
