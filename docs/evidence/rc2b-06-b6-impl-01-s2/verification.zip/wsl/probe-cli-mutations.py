#!/usr/bin/env python3
"""Non-privileged S2 installed-payload CLI probes against an ext4 candidate."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> int:
    if len(sys.argv) != 4:
        raise SystemExit("usage: probe-cli-mutations.py <candidate> <source-archive-root> <output-dir>")
    candidate = Path(sys.argv[1]).resolve(strict=True)
    source = Path(sys.argv[2]).resolve(strict=True)
    output = Path(sys.argv[3]).resolve(strict=True)
    if os.geteuid() == 0:
        raise SystemExit("refusing to run as root")
    install_tool = source / "eng/InstallTool/bin/Release/net10.0/InstallTool.dll"
    if not install_tool.is_file():
        raise SystemExit(f"InstallTool not built: {install_tool}")
    probe_root = Path("/tmp") / ("gagamba-cli-probes-" + os.urandom(6).hex())
    probe_root.mkdir(mode=0o700)
    rows: list[str] = [f"uid={os.geteuid()}", f"candidate={candidate}", f"probeRoot={probe_root}"]

    def flush() -> None:
        (output / "cli-mutation-probes.txt").write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")

    def check(label: str, path: Path, expected: int | None) -> subprocess.CompletedProcess[str]:
        args = ["dotnet", str(install_tool), label]
        if label != "verify-active": args.append(str(path))
        proc = subprocess.run(args, text=True, capture_output=True)
        rows.append(f"{label} {path}: exit={proc.returncode} expected={expected}")
        if proc.stdout.strip(): rows.append("stdout: " + proc.stdout.strip().replace("\n", " | "))
        if proc.stderr.strip(): rows.append("stderr: " + proc.stderr.strip().replace("\n", " | "))
        flush()
        if expected is None:
            if label == "verify-active":
                text = (proc.stdout + proc.stderr).strip()
                if proc.returncode not in (0, 1) or not text.startswith(("Qualified ", "Installed/Unqualified ", "Unqualified ", "Unavailable ")):
                    raise RuntimeError(f"verify-active did not return a recognized read-only state: exit={proc.returncode}, output={text!r}")
        elif (proc.returncode == 0) != (expected == 0):
            raise RuntimeError(f"unexpected {label} exit for {path}: {proc.returncode}")
        return proc

    check("check-payload", candidate, 0)
    check("verify-active", Path("/"), None)
    check("check-staged", candidate, 1)

    baseline = json.loads((candidate / "manifest.json").read_bytes())

    def clone(name: str) -> Path:
        dest = probe_root / name
        shutil.copytree(candidate, dest, symlinks=True)
        return dest

    def refresh_manifest(root: Path) -> None:
        raw = json.loads((root / "manifest.json").read_bytes())
        for item in raw["artifacts"]:
            path = root / item["path"]
            item["length"] = path.stat().st_size
            item["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        manifest_path = root / "manifest.json"
        os.chmod(manifest_path, 0o644)
        manifest_path.write_bytes(json.dumps(raw, ensure_ascii=True, separators=(",", ":")).encode("ascii"))
        os.chmod(manifest_path, 0o444)
        rows.append(f"recomputed-manifest {root.name} sha256={hashlib.sha256(manifest_path.read_bytes()).hexdigest()}")
        flush()

    # Attacker recomputes per-artifact hashes and the outer artifact-set digest.
    # Installed M1 policy still rejects the instrumented Debug bytes.
    debug_m1 = source / "src/Gagamba.Execution.Linux.M1/bin/Debug/net10.0/Gagamba.Execution.Linux.M1.dll"
    if not debug_m1.is_file():
        raise RuntimeError(f"actual Debug M1 build is unavailable: {debug_m1}")
    rows.append(f"debug-M1 source={debug_m1} sha256={hashlib.sha256(debug_m1.read_bytes()).hexdigest()}")
    flush()
    managed = clone("recomputed-debug-m1")
    for component in ("provider", "owner", "recovery"):
        target = managed / component / "Gagamba.Execution.Linux.M1.dll"
        os.chmod(target, 0o644)
        shutil.copyfile(debug_m1, target)
        os.chmod(target, 0o444)
    refresh_manifest(managed)
    check("check-payload", managed, 1)

    # Compile a committed test-only coordinator, but never execute it.
    native_src = source / "tests/Fixtures/wp05-qualification-coordinator.c"
    native_hdr = source / "native/linux-m1"
    test_elf = probe_root / "wp05-qualification-coordinator"
    subprocess.run([
        "gcc", "-static", "-O2", "-s", "-fno-ident",
        "-frandom-seed=gagamba-wp05-qualification", "-Wl,--build-id=none",
        "-I", str(native_hdr), "-o", str(test_elf), str(native_src),
    ], check=True)
    rows.append(f"test-ELF source={native_src} sha256={hashlib.sha256(native_src.read_bytes()).hexdigest()} binarySha256={hashlib.sha256(test_elf.read_bytes()).hexdigest()}")
    flush()
    native = clone("recomputed-test-elf")
    target = native / "native/exec-coordinator"
    os.chmod(target, 0o755)
    shutil.copyfile(test_elf, target)
    os.chmod(target, 0o555)
    refresh_manifest(native)
    check("check-payload", native, 1)

    # Each config mutation has a refreshed file hash/length and canonical outer manifest.
    baseline_deps = next(a["path"] for a in baseline["artifacts"] if a["path"].endswith(".deps.json"))
    deps = clone("deps-extra-native")
    deps_path = deps / baseline_deps
    deps_json = json.loads(deps_path.read_bytes())
    target_name = deps_json["runtimeTarget"]["name"]
    first = next(iter(deps_json["targets"][target_name]))
    deps_json["targets"][target_name][first]["native"] = {"libuntrusted.so": {}}
    os.chmod(deps_path, 0o644)
    deps_path.write_text(json.dumps(deps_json, separators=(",", ":")), encoding="utf-8")
    os.chmod(deps_path, 0o444)
    refresh_manifest(deps)
    check("check-payload", deps, 1)

    deps2 = clone("deps-extra-managed")
    deps_path2 = deps2 / baseline_deps
    deps_json2 = json.loads(deps_path2.read_bytes())
    target_name2 = deps_json2["runtimeTarget"]["name"]
    deps_json2["targets"][target_name2]["Test.Attacker/1.0.0"] = {"runtime": {"Test.Attacker.dll": {}}}
    os.chmod(deps_path2, 0o644)
    deps_path2.write_text(json.dumps(deps_json2, separators=(",", ":")), encoding="utf-8")
    os.chmod(deps_path2, 0o444)
    refresh_manifest(deps2)
    check("check-payload", deps2, 1)

    runtime_path = next(a["path"] for a in baseline["artifacts"] if a["path"].endswith(".runtimeconfig.json"))
    runtime = clone("runtimeconfig-wrong-framework")
    runtime_file = runtime / runtime_path
    runtime_json = json.loads(runtime_file.read_bytes())
    runtime_json["runtimeOptions"]["framework"]["version"] = "10.0.99"
    os.chmod(runtime_file, 0o644)
    runtime_file.write_text(json.dumps(runtime_json, separators=(",", ":")), encoding="utf-8")
    os.chmod(runtime_file, 0o444)
    refresh_manifest(runtime)
    check("check-payload", runtime, 1)

    check("check-payload", candidate, 0)
    install_program = source / "eng/InstallTool/Program.cs"
    if "check-platform" in install_program.read_text(encoding="utf-8"):
        manifest = candidate / "manifest.json"
        platform_probe = check("check-platform", manifest, None)
        root_stat = os.stat("/")
        rows.append(f"host-root-metadata: uid={root_stat.st_uid} gid={root_stat.st_gid} mode={root_stat.st_mode & 0o7777:04o}")
        if platform_probe.returncode == 0:
            changed = json.loads(manifest.read_bytes())
            changed["platform"]["dotnetHostSha256"] = "1" * 64
            bad_manifest = output / "platform-mismatch-manifest.json"
            bad_manifest.write_bytes(json.dumps(changed, ensure_ascii=True, separators=(",", ":")).encode("ascii"))
            check("check-platform", bad_manifest, 1)
        elif (root_stat.st_uid, root_stat.st_gid, root_stat.st_mode & 0o777) == (0, 0, 0o777) and "Directory is group/other writable." in platform_probe.stderr:
            rows.append("check-platform-mismatch: NOT RUN; valid manifest is refused because WSL host / is root:root mode 0777, so an invalid hash would be masked by the same host-baseline failure")
        else:
            raise RuntimeError(f"check-platform refused for an unclassified reason: {platform_probe.stderr.strip()}")
    (output / "cli-mutation-probes.txt").write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")
    (output / "cli-mutation-probes.exit.txt").write_text("0\n", encoding="ascii", newline="\n")
    print("\n".join(rows))
    print(f"probe evidence: {output / 'cli-mutation-probes.txt'}")
    print(f"probe fixtures retained under ext4: {probe_root}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"probe failed: {exc}", file=sys.stderr)
        raise
