#!/usr/bin/env python3
"""Bounded unprivileged Linux ptrace races against candidate copies only."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

PTRACE_TRACEME = 0
PTRACE_SYSCALL = 24
PTRACE_GETREGS = 12
PTRACE_SETOPTIONS = 0x4200
PTRACE_O_TRACESYSGOOD = 1
SYSCALL_STOP = signal.SIGTRAP | 0x80


class Registers(ctypes.Structure):
    _fields_ = [(name, ctypes.c_ulonglong) for name in (
        "r15 r14 r13 r12 rbp rbx r11 r10 r9 r8 rax rcx rdx rsi rdi "
        "orig_rax rip cs eflags rsp ss fs_base gs_base ds es fs gs"
    ).split()]


libc = ctypes.CDLL(None, use_errno=True)
libc.ptrace.restype = ctypes.c_long
libc.ptrace.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p]


def ptrace(request: int, pid: int, addr=0, data=0) -> None:
    rc = libc.ptrace(request, pid, ctypes.c_void_p(addr) if isinstance(addr, int) else addr,
                     ctypes.c_void_p(data) if isinstance(data, int) else data)
    if rc == -1:
        err = ctypes.get_errno()
        raise OSError(err, os.strerror(err))


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def cli(tool: Path, command: str, path: Path | None = None) -> subprocess.CompletedProcess[str]:
    args = ["dotnet", str(tool), command]
    if path is not None:
        args.append(str(path))
    return subprocess.run(args, text=True, capture_output=True, timeout=30)


def traced(command: list[str], hook) -> tuple[int, bool, str]:
    pid = os.fork()
    if pid == 0:
        try:
            ptrace(PTRACE_TRACEME, 0)
            os.kill(os.getpid(), signal.SIGSTOP)
            os.execvpe(command[0], command, os.environ.copy())
        except BaseException as exc:
            print(f"child trace setup failed: {exc}", file=sys.stderr)
            os._exit(127)
    seen = False
    inside_syscall = False
    trace_lines: list[str] = []
    try:
        _, status = os.waitpid(pid, 0)
        if not os.WIFSTOPPED(status):
            raise RuntimeError(f"tracee did not stop before exec: {status}")
        ptrace(PTRACE_SETOPTIONS, pid, 0, PTRACE_O_TRACESYSGOOD)
        ptrace(PTRACE_SYSCALL, pid, 0, 0)
        while True:
            waited, status = os.waitpid(pid, 0)
            if waited != pid:
                continue
            if os.WIFEXITED(status):
                return os.WEXITSTATUS(status), seen, "\n".join(trace_lines)
            if os.WIFSIGNALED(status):
                return 128 + os.WTERMSIG(status), seen, "\n".join(trace_lines)
            if not os.WIFSTOPPED(status):
                ptrace(PTRACE_SYSCALL, pid, 0, 0)
                continue
            stopped = os.WSTOPSIG(status)
            if stopped == SYSCALL_STOP:
                if not inside_syscall:
                    regs = Registers()
                    ptrace(PTRACE_GETREGS, pid, 0, ctypes.byref(regs))
                    if not seen:
                        event = hook(pid, int(regs.orig_rax), regs)
                        if event:
                            seen = True
                            trace_lines.append(event)
                    inside_syscall = True
                else:
                    inside_syscall = False
                ptrace(PTRACE_SYSCALL, pid, 0, 0)
            else:
                # Suppress only the tracer's initial/exec SIGTRAP; deliver other signals.
                deliver = 0 if stopped in (signal.SIGSTOP, signal.SIGTRAP) else stopped
                ptrace(PTRACE_SYSCALL, pid, 0, deliver)
    except BaseException:
        try:
            os.kill(pid, signal.SIGKILL)
            os.waitpid(pid, 0)
        except OSError:
            pass
        raise


def fd_target(pid: int, fd: int) -> str | None:
    try:
        return os.readlink(f"/proc/{pid}/fd/{fd}")
    except OSError:
        return None


def main() -> int:
    if len(sys.argv) != 4:
        raise SystemExit("usage: ptrace-race-probes.py <candidate> <source-root> <output-dir>")
    candidate = Path(sys.argv[1]).resolve(strict=True)
    source = Path(sys.argv[2]).resolve(strict=True)
    output = Path(sys.argv[3]).resolve(strict=True)
    if os.geteuid() == 0:
        raise SystemExit("refusing to run as root")
    if not hasattr(os, "uname") or os.uname().machine != "x86_64":
        raise SystemExit("ptrace probe requires Linux x86_64")
    tool = source / "eng/InstallTool/bin/Release/net10.0/InstallTool.dll"
    if not tool.is_file():
        raise SystemExit(f"InstallTool not built: {tool}")
    work = Path("/tmp") / ("gagamba-ptrace-races-" + os.urandom(6).hex())
    work.mkdir(mode=0o700)
    records = [f"uid={os.geteuid()}", f"candidate={candidate}", f"work={work}"]

    positive = cli(tool, "check-payload", candidate)
    records.append(f"positive-before: exit={positive.returncode}; stdout={positive.stdout.strip()!r}; stderr={positive.stderr.strip()!r}")
    if positive.returncode != 0:
        raise RuntimeError("original candidate positive control failed")

    # Change only mtime/ctime after the verifier has acquired the matching file fd,
    # before its first read. Keep file bytes and mode identical.
    time_root = work / "time-race"
    shutil.copytree(candidate, time_root)
    target = time_root / "owner/Gagamba.Execution.Linux.M1.dll"
    before_hash, before_mode = sha(target), target.stat().st_mode & 0o7777
    hit = {"value": False}

    def time_hook(pid: int, syscall_no: int, regs: Registers) -> str | None:
        # x86_64 read=0, pread64=17; rdi is fd.
        if syscall_no not in (0, 17):
            return None
        descriptor = int(regs.rdi)
        if fd_target(pid, descriptor) != str(target):
            return None
        os.utime(target, None)
        after_stat = target.stat()
        if sha(target) != before_hash or after_stat.st_mode & 0o7777 != before_mode:
            raise RuntimeError("timestamp probe unexpectedly altered file bytes/mode")
        hit["value"] = True
        return f"timestamp-hook: syscall={syscall_no} fd={descriptor} target={target}; mode={before_mode:04o}; sha256 unchanged={before_hash}; mtime_ns={after_stat.st_mtime_ns}; ctime_ns={after_stat.st_ctime_ns}"

    rc, seen, trace = traced(["dotnet", str(tool), "check-payload", str(time_root)], time_hook)
    records.append("changed-during-hash: " + (trace or "hook not reached"))
    records.append(f"changed-during-hash: exit={rc}; hookSeen={seen}; stdout/stderr emitted by child")
    if not seen or rc == 0:
        records.append("changed-during-hash: NOT DEMONSTRATED (expected syscall hook plus verifier refusal)")

    # Swap a same-content directory at the requested root during the first root
    # getdents64 call. The verifier continues through its open fd and must reject
    # when it reacquires the original path at the end.
    gen_root = work / "generation-race"
    replacement = work / "generation-replacement"
    old = work / "generation-original-held"
    shutil.copytree(candidate, gen_root)
    shutil.copytree(candidate, replacement)
    gen_hit = {"value": False}

    def generation_hook(pid: int, syscall_no: int, regs: Registers) -> str | None:
        # x86_64 getdents64=217; rdi is dirfd.
        if syscall_no != 217:
            return None
        descriptor = int(regs.rdi)
        if fd_target(pid, descriptor) != str(gen_root):
            return None
        os.rename(gen_root, old)
        os.rename(replacement, gen_root)
        gen_hit["value"] = True
        return f"generation-replacement-hook: syscall=getdents64 fd={descriptor}; path={gen_root}; originalInode={old.stat().st_ino}; replacementInode={gen_root.stat().st_ino}"

    rc2, seen2, trace2 = traced(["dotnet", str(tool), "check-payload", str(gen_root)], generation_hook)
    records.append("generation-replacement: " + (trace2 or "hook not reached"))
    records.append(f"generation-replacement: exit={rc2}; hookSeen={seen2}; stdout/stderr emitted by child")
    if not seen2 or rc2 == 0:
        records.append("generation-replacement: NOT DEMONSTRATED (expected syscall hook plus verifier refusal)")

    positive_after = cli(tool, "check-payload", candidate)
    records.append(f"positive-after: exit={positive_after.returncode}; stdout={positive_after.stdout.strip()!r}; stderr={positive_after.stderr.strip()!r}")
    if positive_after.returncode != 0:
        raise RuntimeError("original candidate positive control failed after isolated race probes")

    result = "\n".join(records) + "\n"
    (output / "ptrace-race-probes.txt").write_text(result, encoding="utf-8", newline="\n")
    print(result, end="")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ptrace probe error: {exc}", file=sys.stderr)
        raise
