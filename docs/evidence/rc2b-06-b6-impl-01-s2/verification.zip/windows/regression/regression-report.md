# Final Windows regression evidence (2026-11-02)

## Source and isolation

Final source: commit `8b897e4ebb8e53385199083a38086a9713f0e07a`, tree `af1dc67cf6c74979eb24e9395724b86f264f9a3f` (`final-source-identity.txt`). A tracked-file archive is at `source-8b897e4`. All final D6.4 and supplemental outputs live in that archive under `artifacts/`; other project builds use separate `--artifacts-path` roots in this validation directory. The canonical checkout received no build outputs from these runs.

For test builds, `-p:NuGetAudit=false` suppressed only the unavailable NuGet vulnerability-audit request (api.nuget.org is unreachable in this sandbox). The official supplemental script was run unchanged; its child process received `NuGetAudit=false` in its environment. SDK: .NET 10.0.401.

## Seven Debug project suites on final commit

| Project | Passed | Failed | Environment skips | Exit |
|---|---:|---:|---:|---:|
| Conformance | 6 | 0 | 0 | 0 |
| Linux | 26 | 0 | 16 | 0 |
| macOS | 47 | 0 | 4 | 0 |
| Execution | 68 | 0 | 0 | 0 |
| Windows | 30 | 0 | 0 | 0 |
| Runtime | 15 | 0 | 0 | 0 |
| Fixture SelfTest | 15 | 0 | 0 | 0 |

Exact commands and logs are in `final-<Project>.log`; TRX files are in `trx-final-<Project>/`. The JSON inventory is `final-seven-summary.json`.

## M1, B5, and D6.4

- **M1 Debug, final commit:** 1,113 passed, 0 failed, 270 not executed (environment skips), total 1,383. Raw TRX: `../windows-final-m1.trx`.
- **M1 Release runner, final commit:** 1,113 passed, 0 failed, 270 skipped, total 1,383. Command/log: `M1ReleaseRunner-final.log`; TRX: `trx-M1ReleaseRunner-final/Laszlos_LAPTOP-KBD8D8JG_2026-11-02_16_00_45_net10.0.trx`.
- **Supplemental actual-Release-M1, official script unchanged:** 1,082 passed, 0 failed, 200 skipped, total 1,282. Command output: `official-supplemental.log`; script-generated log/TRX: `source-8b897e4/artifacts/official-production-regressions/production-regressions.log` and `source-8b897e4/artifacts/official-production-regressions/trx/Laszlos_LAPTOP-KBD8D8JG_2026-11-02_16_00_15_net10.0.trx`.
- **B5 C3 cases:** 61/61 passed, 0 skipped in each final M1 Debug, M1 Release runner, and supplemental actual-Release-M1 TRX.
- **D6.4 fixture:** Debug 3/3 passed and Release 3/3 passed, 0 skipped. Commands/logs: `final-D64-Debug.log`, `final-D64-Release.log`; TRX in `trx-final-D64-Debug/` and `trx-final-D64-Release/`. `--artifacts-path` is intentionally omitted because the project rejects remapping for its `d6-4-variant`; its project-defined intermediate/binary roots remain inside `source-8b897e4`.
- **S1 production binary verifier matrix:** parent-run `../s1-final/results.json` records 51/51 probes passing, zero failed. S1 binary hashes and per-probe logs are in `../s1-final/`.

The earlier `35e74fda` exploratory supplemental run is superseded. On final commit `8b897e4`, the official script includes the golden resource and the updated Release-variant assertion; the complete final result above passed.

No privileged actions or WSL-native qualification tests were run as part of this Windows regression pass.
