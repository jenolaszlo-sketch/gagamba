$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:\Users\Laszlos\source\repos\Gagamba'
$root='artifacts/rc2b-06-b6-s3-resume/baseline'
foreach($project in @('Gagamba.Execution.Tests','Gagamba.Execution.Windows.Tests','Gagamba.Execution.Linux.Tests','Gagamba.Execution.MacOS.Tests','Gagamba.Runtime.Tests','Gagamba.Conformance.Tests')) {
    dotnet test "tests/$project/$project.csproj" -c Debug --no-restore --logger "trx;LogFileName=$project.trx" --results-directory "$root/$project" -v:q *> "$root-$project.log"
    if($LASTEXITCODE){Get-Content "$root-$project.log" -Tail 20;exit $LASTEXITCODE}
}
foreach($configuration in @('Debug','Release')) {
    dotnet test tests/Gagamba.Execution.Linux.M1.D6_4.Tests -c $configuration --no-restore --logger 'trx;LogFileName=d64.trx' --results-directory "$root/d64-$configuration" -v:q *> "$root-d64-$configuration.log"
    if($LASTEXITCODE){Get-Content "$root-d64-$configuration.log" -Tail 20;exit $LASTEXITCODE}
}
dotnet test tests/Fixtures/Gagamba.Fixture.SelfTest -c Debug --no-restore --logger 'trx;LogFileName=fixture.trx' --results-directory "$root/fixture" -v:q *> "$root-fixture.log"
if($LASTEXITCODE){Get-Content "$root-fixture.log" -Tail 20;exit $LASTEXITCODE}
Write-Output 'Baseline projects, D6.4 variants and fixture self-test completed.'
