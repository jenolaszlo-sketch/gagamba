$ErrorActionPreference='Stop'
$repo='C:\Users\Laszlos\source\repos\Gagamba'
Set-Location -LiteralPath $repo
dotnet build src/Gagamba.Execution.Linux.M1.Recovery/Gagamba.Execution.Linux.M1.Recovery.csproj --no-restore -v:q *> artifacts/rc2b-06-b6-s3-resume-recovery-debug.log
if($LASTEXITCODE){exit $LASTEXITCODE}
dotnet build tests/Fixtures/B2Controller/B2Controller.csproj --no-restore -v:q *> artifacts/rc2b-06-b6-s3-resume-fixture-debug.log
if($LASTEXITCODE){exit $LASTEXITCODE}
dotnet test tests/Gagamba.Execution.Linux.M1.Tests -c Release --no-restore --logger 'trx;LogFileName=s3-release-runner.trx' --results-directory artifacts/rc2b-06-b6-s3-resume/release-runner -v:q *> artifacts/rc2b-06-b6-s3-resume-release-runner.log
if($LASTEXITCODE){Get-Content artifacts/rc2b-06-b6-s3-resume-release-runner.log -Tail 15;exit $LASTEXITCODE}
& ./eng/test-production-regressions.ps1 -EvidenceDirectory artifacts/rc2b-06-b6-s3-resume/production-regressions *> artifacts/rc2b-06-b6-s3-resume-production-regressions.log
if($LASTEXITCODE){Get-Content artifacts/rc2b-06-b6-s3-resume-production-regressions.log -Tail 15;exit $LASTEXITCODE}
Get-Content artifacts/rc2b-06-b6-s3-resume-release-runner.log -Tail 6
Get-Content artifacts/rc2b-06-b6-s3-resume-production-regressions.log -Tail 6
