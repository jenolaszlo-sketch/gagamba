from pathlib import Path
import os,stat,subprocess,json
R=Path('/mnt/c/Users/Laszlos/source/repos/Gagamba');OUT=R/'artifacts/rc2b-06-b6-s3-resume'
assert os.getuid()==1000
result=subprocess.run(['dotnet',str(OUT/'native-release-build/bin/InstallTool/release/InstallTool.dll'),'verify-active'],capture_output=True,text=True,cwd=R)
(OUT/'verify-active-refusal.log').write_text(result.stdout+result.stderr+'EXPECTED_REFUSAL_EXIT='+str(result.returncode)+'\n')
assert result.returncode==1 and result.stdout.startswith('Unqualified ')
root=os.stat('/');assert root.st_uid==0 and root.st_gid==0 and stat.S_IMODE(root.st_mode)==0o777
remaining=[]
names={'Gagamba.Execution.Linux.M1.Owner.dll','Gagamba.Execution.Linux.M1.Recovery.dll','Gagamba.Execution.Linux.M1.B2Controller.dll'}
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
        if p.stat().st_uid!=os.getuid():continue
        args=(p/'cmdline').read_bytes().split(b'\0')
        if any(Path(arg.decode(errors='replace')).name in names for arg in args if arg):remaining.append(int(p.name))
    except (FileNotFoundError,ProcessLookupError,PermissionError):pass
facts=dict(uid=os.getuid(),gid=os.getgid(),root=dict(uid=root.st_uid,gid=root.st_gid,mode=oct(stat.S_IMODE(root.st_mode))),
    installationExists=Path('/opt/gagamba').exists(),inspectionExit=result.returncode,inspection=result.stdout.strip(),
    knownHelperProcessesRemaining=remaining,scope='Read-only host observation; no installed qualification or permission change')
(OUT/'native-host-and-cleanup.json').write_text(json.dumps(facts,indent=2)+'\n')
assert not remaining,remaining
print(json.dumps(facts))
