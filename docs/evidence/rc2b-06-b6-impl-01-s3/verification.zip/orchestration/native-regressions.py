from pathlib import Path
import os,shutil,subprocess,tarfile,json,hashlib,uuid
R=Path('/mnt/c/Users/Laszlos/source/repos/Gagamba')
OUT=R/'artifacts/rc2b-06-b6-s3-resume'
WORK=Path('/tmp/gagamba-s3-resume-20261104-fixtures-'+uuid.uuid4().hex)
assert os.getuid()==1000
WORK.mkdir(exist_ok=False)
fixture=WORK/'roles';fixture.mkdir(mode=0o700)
for role,src,entry in [('recovery','src/Gagamba.Execution.Linux.M1.Recovery/bin/Debug/net10.0','Gagamba.Execution.Linux.M1.Recovery'),
                       ('owner','src/Gagamba.Execution.Linux.M1.Owner/bin/Debug/net10.0','Gagamba.Execution.Linux.M1.Owner'),
                       ('controller','tests/Fixtures/B2Controller/bin/Debug/net10.0','Gagamba.Execution.Linux.M1.B2Controller')]:
    dest=fixture/role;dest.mkdir(mode=0o700)
    for name in [entry+'.dll',entry+'.deps.json',entry+'.runtimeconfig.json','Gagamba.Execution.Linux.M1.dll','Gagamba.Execution.dll']:
        shutil.copyfile(R/src/name,dest/name);(dest/name).chmod(0o600)
def run(name,args,env=None):
    with (OUT/(name+'.log')).open('w') as f:
        f.write('COMMAND '+json.dumps(args)+'\n');f.flush()
        p=subprocess.run(args,cwd=R,env=env or os.environ,stdout=f,stderr=subprocess.STDOUT,timeout=240)
    print(name,p.returncode,flush=True);return p.returncode
codes={}
codes['b2-legacy']=run('b2-legacy',['python3','-B','eng/qualify-b2.py','--installation',str(fixture),'--artifacts',str(OUT/'b2-legacy')])
# The 14-file accepted S2 archive is only an unprivileged payload fixture, never an installed selection.
with tarfile.open(R/'docs/evidence/rc2b-06-b6-impl-01-s2/candidate-payload.tar.gz') as archive:
    archive.extractall(WORK,filter='data')
env=os.environ.copy();env['GAGAMBA_S2_TEST_CANDIDATE']=str(WORK/'candidate')
env['GAGAMBA_OWNER_DLL']=str(fixture/'owner/Gagamba.Execution.Linux.M1.Owner.dll')
env['GAGAMBA_B2_CONTROLLER_DLL']=str(fixture/'controller/Gagamba.Execution.Linux.M1.B2Controller.dll')
env['GAGAMBA_INT01_NATIVE_PRIMITIVES']='1'
env['GAGAMBA_INT01_EVIDENCE']=str(OUT/'legacy-primitives');(OUT/'legacy-primitives').mkdir(exist_ok=True)
tests='tests/Gagamba.Execution.Linux.M1.Tests/bin/Debug/net10.0/Gagamba.Execution.Linux.M1.Tests.dll'
codes['legacy-and-s2']=run('native-legacy-and-s2',['dotnet','vstest',tests,
    '--TestCaseFilter:FullyQualifiedName~InstalledFileSystemNativeTests|FullyQualifiedName~DirectAuthenticationTests|FullyQualifiedName~OwnerSafetyMonitorTests|FullyQualifiedName~RecoveryB2NativeTests|FullyQualifiedName~Wp05B5C3',
    '--logger:trx;LogFileName=s3-legacy-and-s2.trx','--ResultsDirectory:'+str(OUT/'legacy-primitives')],env)
codes['s2-transactions']=run('s2-transactions',['python3','-IB','eng/linux-m1/tests/test_install_common.py'])
(OUT/'native-regression-results.json').write_text(json.dumps(codes,indent=2))
# Preserve role files/candidate and all logs for review; no host installation or cgroup provisioning.
raise SystemExit(1 if any(codes.values()) else 0)
