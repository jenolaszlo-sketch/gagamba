$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:\Users\Laszlos\source\repos\Gagamba'
dotnet test tests/Gagamba.Execution.Linux.M1.Tests --no-restore --logger 'trx;LogFileName=s3-debug.trx' --results-directory artifacts/rc2b-06-b6-s3-resume/debug -v:q *> artifacts/rc2b-06-b6-s3-resume-debug.log
if($LASTEXITCODE){exit $LASTEXITCODE}
& 'C:\Users\Laszlos\source\repos\Solo\artifacts\gagamba-s3-resume-20261104\final-builds.ps1'
if($LASTEXITCODE){exit $LASTEXITCODE}
dotnet build tests/Fixtures/B2Controller/B2Controller.csproj -c Release --artifacts-path artifacts/rc2b-06-b6-s3-resume/native-release-build --no-restore -v:q *> artifacts/rc2b-06-b6-s3-resume-native-release-build.log
if($LASTEXITCODE){exit $LASTEXITCODE}
dotnet build eng/InstallTool/InstallTool.csproj -c Release --artifacts-path artifacts/rc2b-06-b6-s3-resume/native-release-build --no-restore -v:q *> artifacts/rc2b-06-b6-s3-resume-install-inspector-build.log
if($LASTEXITCODE){exit $LASTEXITCODE}
wsl -d Ubuntu -u gaga -- sh -c 'cd /mnt/c/Users/Laszlos/source/repos/Gagamba && GAGAMBA_S3_OBSERVATIONS=/mnt/c/Users/Laszlos/source/repos/Gagamba/artifacts/rc2b-06-b6-s3-resume/native-production/observations GAGAMBA_S3_EVIDENCE_FIXTURE=/mnt/c/Users/Laszlos/source/repos/Gagamba/artifacts/rc2b-06-b6-s3-resume/native-release-build/bin/B2Controller/release/Gagamba.Execution.Linux.M1.B2Controller.dll dotnet vstest artifacts/rc2b-06-b6-s3-resume/production-regressions/bin/Release/net10.0/Gagamba.Execution.Linux.M1.Tests.dll --TestCaseFilter:"FullyQualifiedName~QualifiedLauncherNativeTests|FullyQualifiedName~B2EvidenceNativeTests|FullyQualifiedName~InstallationHandshakeTests|FullyQualifiedName~InstallationWireTests|FullyQualifiedName~LoadedMappingTests" --logger:"trx;LogFileName=s3-native-production.trx" --ResultsDirectory:artifacts/rc2b-06-b6-s3-resume/native-production > artifacts/rc2b-06-b6-s3-resume-native-production.log 2>&1'
if($LASTEXITCODE){Get-Content artifacts/rc2b-06-b6-s3-resume-native-production.log -Tail 30;exit $LASTEXITCODE}
wsl -d Ubuntu -u gaga -- python3 -B /mnt/c/Users/Laszlos/source/repos/Solo/artifacts/gagamba-s3-resume-20261104/native-regressions.py
if($LASTEXITCODE){exit $LASTEXITCODE}
wsl -d Ubuntu -u gaga -- python3 -B /mnt/c/Users/Laszlos/source/repos/Solo/artifacts/gagamba-s3-resume-20261104/inspect-native.py
if($LASTEXITCODE){exit $LASTEXITCODE}
Get-Content artifacts/rc2b-06-b6-s3-resume/verify-active-refusal.log
Get-Content artifacts/rc2b-06-b6-s3-resume-native-production.log -Tail 3
