using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.Json;
using Gagamba.Execution.Linux.M1.Bootstrap;
using Gagamba.Execution.Linux.M1.Installed;
using Gagamba.Execution.Linux.M1.Native;
using Microsoft.Win32.SafeHandles;

// Archived external adversarial peer, exact committed Release M1 reference.
// No installed result, staging, domain, writer or RELEASE route.
static class BufferBoundaryProbe
{
    static InstallationIdentity Identity=>new(new('1',64),new('2',64),new('3',64),new('4',64),new('5',64),new('6',64),1,1,1,1,"ae4-linux-fixed-fixture-v1","1",new('1',64),true);
    static void Need(bool ok,string reason){if(!ok)throw new IOException(reason);}
    static int Main(string[] args)
    {
        if(args.Length==5 && args[0]=="--sender")
        {
            var session=Guid.Parse(args[1]);var execution=Guid.Parse(args[2]);var lease=Guid.Parse(args[3]);int size=int.Parse(args[4]);
            Need(PidFd.TryOpen(RecoveryInterop.GetParentPid(),out int pin,out _),"parent pin");using var retained=new SafeFileHandle((IntPtr)pin,true);
            long d=InstallationDeadline.Create();using var socket=B2EvidenceSocket.Connect(session,d,()=>{});var seq=new OwnerProtocolSequencer(execution,lease);
            _=socket.Receive(seq,OwnerProtocolMessageType.B2OwnerExpectation,B2ProcessIdentity.Identity(RecoveryInterop.GetParentPid()),pin,d,()=>{});
            byte[] payload=size==76?InstallationWire.Echo(Identity,1):new byte[size];
            Need(FdPassing.TrySendMessage(socket.Descriptor,seq.Create(OwnerProtocolMessageType.OwnerInstallationEcho,payload),out _),"send mutation");
            DirectUnix.Shutdown(socket.Descriptor,1);Console.WriteLine("SENT");Console.Out.Flush();Console.ReadLine();return 0;
        }
        var results=new List<object>();
        foreach(int size in new[]{76,1024})
        {
            var session=Guid.NewGuid();var execution=Guid.NewGuid();var lease=Guid.NewGuid();using var listener=B2EvidenceSocket.Listen(session);
            var psi=new ProcessStartInfo("/usr/lib/dotnet/dotnet"){UseShellExecute=false,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true};
            foreach(string a in new[]{Assembly.GetExecutingAssembly().Location,"--sender",session.ToString(),execution.ToString(),lease.ToString(),size.ToString()})psi.ArgumentList.Add(a);
            using var child=Process.Start(psi)!;Need(PidFd.TryOpen(child.Id,out int pin,out _),"original child pin");using var retained=new SafeFileHandle((IntPtr)pin,true);
            int flags=0;long peek=-1;bool accepted=false;string? refusal=null;
            try
            {
                long d=InstallationDeadline.Create();using var socket=listener.Accept(d,()=>{});using var peer=DirectPeerIdentity.Verify(socket.Descriptor,B2ProcessIdentity.Identity(child.Id),pin);
                var seq=new OwnerProtocolSequencer(execution,lease);socket.Send(seq,OwnerProtocolMessageType.B2OwnerExpectation,InstallationWire.Expectation(session,Identity),d,()=>{});
                Need(child.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(5)).GetAwaiter().GetResult()=="SENT","explicit queued-frame barrier");
                if(size==1024)
                {
                    var bytes=new byte[561];var control=new byte[4096];var dataPin=GCHandle.Alloc(bytes,GCHandleType.Pinned);var ctrlPin=GCHandle.Alloc(control,GCHandleType.Pinned);var iov=Marshal.AllocHGlobal(16);
                    try
                    {
                        Marshal.StructureToPtr(new DirectUnix.Iovec{Base=dataPin.AddrOfPinnedObject(),Length=(UIntPtr)bytes.Length},iov,false);
                        var msg=new DirectUnix.Message{Vectors=iov,VectorCount=(UIntPtr)1,Control=ctrlPin.AddrOfPinnedObject(),ControlLength=(UIntPtr)control.Length};
                        peek=DirectUnix.Receive(socket.Descriptor,ref msg,2|0x40|0x40000000);flags=msg.Flags;
                        Need(peek==561 && (flags&0x20)!=0,"actual kernel MSG_TRUNC must be observed before production receive");
                    }
                    finally{Marshal.FreeHGlobal(iov);ctrlPin.Free();dataPin.Free();}
                }
                try{byte[] echo=socket.Receive(seq,OwnerProtocolMessageType.OwnerInstallationEcho,B2ProcessIdentity.Identity(child.Id),pin,d,()=>{});accepted=InstallationWire.CompareEcho(echo,Identity,1)==InstallationMismatch.None;}
                catch(IOException e){refusal=e.Message;}
            }
            finally{child.StandardInput.WriteLine("done");child.StandardInput.Flush();Need(child.WaitForExit(5000),"child reap");}
            Need(child.ExitCode==0,child.StandardError.ReadToEnd());Need(accepted==(size==76),"wrong acceptance");
            if(size==1024)Need(refusal=="evidence ancillary/truncation refused","production truncation gate");
            results.Add(new{PayloadBytes=size,FrameBytes=size+48,Accepted=accepted,KernelPeekBytes=peek,KernelFlags=flags,Refusal=refusal,ChildReaped=true,Scope="native component only; synthetic identity"});
        }
        Console.WriteLine(JsonSerializer.Serialize(new{Passed=2,Failed=0,Results=results},new JsonSerializerOptions{WriteIndented=true}));return 0;
    }
}
