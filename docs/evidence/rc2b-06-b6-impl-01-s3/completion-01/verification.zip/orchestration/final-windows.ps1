$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'C:\Users\Laszlos\source\repos\Gagamba'
if ((git rev-parse HEAD) -ne '0eb7a7174efb04237a7d69732a6589d1e945125c') { throw 'Source changed' }
dotnet test tests/Gagamba.Execution.Linux.M1.Tests -c Debug --no-restore --logger 'trx;LogFileName=completion-debug.trx' --results-directory artifacts/rc2b-06-b6-s3-complete/debug -v:q *> artifacts/rc2b-06-b6-s3-complete-debug.log
if($LASTEXITCODE){Get-Content artifacts/rc2b-06-b6-s3-complete-debug.log -Tail 25;exit $LASTEXITCODE}
dotnet test tests/Gagamba.Execution.Linux.M1.Tests -c Release --no-restore --logger 'trx;LogFileName=completion-release-runner.trx' --results-directory artifacts/rc2b-06-b6-s3-complete/release-runner -v:q *> artifacts/rc2b-06-b6-s3-complete-release-runner.log
if($LASTEXITCODE){Get-Content artifacts/rc2b-06-b6-s3-complete-release-runner.log -Tail 25;exit $LASTEXITCODE}
& ./eng/test-production-regressions.ps1 -EvidenceDirectory artifacts/rc2b-06-b6-s3-complete/production-regressions *> artifacts/rc2b-06-b6-s3-complete-production-regressions.log
if($LASTEXITCODE){Get-Content artifacts/rc2b-06-b6-s3-complete-production-regressions.log -Tail 25;exit $LASTEXITCODE}
& ./eng/test-production-build.ps1 -EvidenceDirectory artifacts/rc2b-06-b6-s3-complete/s1 *> artifacts/rc2b-06-b6-s3-complete-s1.log
if($LASTEXITCODE){Get-Content artifacts/rc2b-06-b6-s3-complete-s1.log -Tail 25;exit $LASTEXITCODE}
dotnet test tests/Fixtures/Gagamba.Fixture.SelfTest --no-restore --logger 'trx;LogFileName=completion-fixture.trx' --results-directory artifacts/rc2b-06-b6-s3-complete/fixture -v:q *> artifacts/rc2b-06-b6-s3-complete-fixture.log
if($LASTEXITCODE){Get-Content artifacts/rc2b-06-b6-s3-complete-fixture.log -Tail 25;exit $LASTEXITCODE}
Get-Content artifacts/rc2b-06-b6-s3-complete-debug.log -Tail 4
Get-Content artifacts/rc2b-06-b6-s3-complete-release-runner.log -Tail 4
Get-Content artifacts/rc2b-06-b6-s3-complete-production-regressions.log -Tail 4
Get-Content artifacts/rc2b-06-b6-s3-complete-s1.log -Tail 4
Get-Content artifacts/rc2b-06-b6-s3-complete-fixture.log -Tail 4
