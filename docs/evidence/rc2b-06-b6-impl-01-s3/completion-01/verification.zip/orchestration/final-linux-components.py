from pathlib import Path
import os,subprocess,shutil,hashlib,json,tarfile,uuid
R=Path('/mnt/c/Users/Laszlos/source/repos/Gagamba');OUT=R/'artifacts/rc2b-06-b6-s3-complete'
assert os.getuid()==1000
source=subprocess.check_output(['git','-c','safe.directory='+str(R),'-C',str(R),'rev-parse','HEAD']).decode().strip();assert source=='0eb7a7174efb04237a7d69732a6589d1e945125c'
fixture=OUT/'release/bin/B2Controller/release/Gagamba.Execution.Linux.M1.B2Controller.dll'
owner=OUT/'release/bin/Gagamba.Execution.Linux.M1.Owner/release/Gagamba.Execution.Linux.M1.Owner.dll'
recovery=OUT/'release/bin/Gagamba.Execution.Linux.M1.Recovery/release/Gagamba.Execution.Linux.M1.Recovery.dll'
def run(name,args,env=None,timeout=300):
    with (OUT/(name+'.log')).open('w') as log:
        log.write('SOURCE '+source+'\nCOMMAND '+json.dumps(args)+'\n');log.flush()
        result=subprocess.run(args,cwd=R,env=env or os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    print(name,result.returncode,flush=True);assert result.returncode==0,name
run('topology-final',['python3','-B','eng/qualify-s3-completion.py','--fixture',str(fixture),'--production-owner',str(owner),'--artifacts',str(OUT/'topology-final')])
run('loaded-final',['python3','-B','eng/qualify-s3-loaded.py','--fixture',str(fixture),'--artifacts',str(OUT/'loaded-final')])
run('production-refusal-final',['python3','-B','eng/qualify-s3-production-refusal.py','--recovery',str(recovery),'--owner',str(owner),'--artifacts',str(OUT/'production-refusal-final')])
private=Path('/tmp/gagamba-s3-complete-regressions-'+uuid.uuid4().hex);private.mkdir(mode=0o700)
for role,entry in [('controller',fixture),('recovery',recovery),('owner',owner)]:
    dest=private/role;dest.mkdir(mode=0o700)
    for name in [entry.name,entry.stem+'.deps.json',entry.stem+'.runtimeconfig.json','Gagamba.Execution.Linux.M1.dll','Gagamba.Execution.dll']:
        shutil.copyfile(entry.parent/name,dest/name);(dest/name).chmod(0o600)
run('legacy-b2-final',['python3','-B','eng/qualify-b2.py','--installation',str(private),'--artifacts',str(OUT/'legacy-b2-final')])
with tarfile.open(R/'docs/evidence/rc2b-06-b6-impl-01-s2/candidate-payload.tar.gz') as archive:archive.extractall(private,filter='data')
env=os.environ.copy();env.update(GAGAMBA_S2_TEST_CANDIDATE=str(private/'candidate'),GAGAMBA_OWNER_DLL=str(private/'owner'/owner.name),
    GAGAMBA_B2_CONTROLLER_DLL=str(private/'controller'/fixture.name),GAGAMBA_INT01_NATIVE_PRIMITIVES='1',GAGAMBA_INT01_EVIDENCE=str(OUT/'mixed-final'))
(OUT/'mixed-final').mkdir(exist_ok=True)
run('mixed-final',['dotnet','vstest','tests/Gagamba.Execution.Linux.M1.Tests/bin/Debug/net10.0/Gagamba.Execution.Linux.M1.Tests.dll',
    '--TestCaseFilter:FullyQualifiedName~InstalledFileSystemNativeTests|FullyQualifiedName~DirectAuthenticationTests|FullyQualifiedName~OwnerSafetyMonitorTests|FullyQualifiedName~RecoveryB2NativeTests|FullyQualifiedName~Wp05B5C3',
    '--logger:trx;LogFileName=completion-mixed.trx','--ResultsDirectory:'+str(OUT/'mixed-final')],env)
run('s2-transactions-final',['python3','-IB','eng/linux-m1/tests/test_install_common.py'])
# The same-entry test-runner ELF is a runtime launcher, never an Owner/Recovery substitution.
dest=OUT/'production-regressions/bin/Release/net10.0/Gagamba.Execution.Linux.M1.Tests'
stub=R/'tests/Gagamba.Execution.Linux.M1.Tests/bin/Debug/net10.0/Gagamba.Execution.Linux.M1.Tests'
assert stub.read_bytes()[:4]==b'\x7fELF';shutil.copyfile(stub,dest)
if not os.access(dest,os.X_OK):
    copied=Path('/tmp/gagamba-s3-production-tests-'+uuid.uuid4().hex);shutil.copytree(dest.parent,copied);dest=copied/dest.name;dest.chmod(0o755)
env=os.environ.copy();env.update(GAGAMBA_S3_EVIDENCE_FIXTURE=str(fixture),GAGAMBA_S3_OBSERVATIONS=str(OUT/'native-production-final/observations'))
run('native-production-final',['dotnet','vstest',str(dest)+'.dll',
    '--TestCaseFilter:FullyQualifiedName~InstallationCompletionTests|FullyQualifiedName~InstallationTransferNativeTests|FullyQualifiedName~InstallationEvidenceEdgeTests|FullyQualifiedName~QualifiedLauncherNativeTests|FullyQualifiedName~B2EvidenceNativeTests|FullyQualifiedName~InstallationHandshakeTests|FullyQualifiedName~InstallationWireTests|FullyQualifiedName~LoadedMappingTests',
    '--logger:trx;LogFileName=completion-native-production.trx','--ResultsDirectory:'+str(OUT/'native-production-final')],env)
(OUT/'linux-final-source.json').write_text(json.dumps(dict(source=source,uid=os.getuid(),gid=os.getgid(),kernel=os.uname().release,
    testApphostSha256=hashlib.sha256(stub.read_bytes()).hexdigest(),fixtureSha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),
    privateRegressions=str(private),scope='Native components and real Release refusal, no trusted installation positive'),indent=2)+'\n')
