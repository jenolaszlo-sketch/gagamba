from pathlib import Path
import os,stat,subprocess,json
R=Path('/mnt/c/Users/Laszlos/source/repos/Gagamba');OUT=R/'artifacts/rc2b-06-b6-s3-complete'
tool=OUT/'release/bin/InstallTool/release/InstallTool.dll'
result=subprocess.run(['dotnet',str(tool),'verify-active'],cwd=R,capture_output=True,text=True)
(OUT/'verify-active-final.log').write_text('COMMAND '+json.dumps(['dotnet',str(tool),'verify-active'])+'\n'+result.stdout+result.stderr+'EXPECTED_REFUSAL_EXIT='+str(result.returncode)+'\n')
assert os.getuid()==1000 and result.returncode==1 and result.stdout.startswith('Unqualified ')
root=os.stat('/');assert root.st_uid==0 and root.st_gid==0 and stat.S_IMODE(root.st_mode)==0o777
names={'Gagamba.Execution.Linux.M1.Owner.dll','Gagamba.Execution.Linux.M1.Recovery.dll','Gagamba.Execution.Linux.M1.B2Controller.dll'};remaining=[]
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:
        if proc.stat().st_uid!=os.getuid():continue
        args=(proc/'cmdline').read_bytes().split(b'\0')
        if any(Path(arg.decode(errors='replace')).name in names for arg in args if arg):remaining.append(int(proc.name))
    except (FileNotFoundError,ProcessLookupError,PermissionError):pass
cgroup=Path('/sys/fs/cgroup');s=cgroup.stat()
facts=dict(uid=os.getuid(),gid=os.getgid(),kernel=os.uname().release,libc=subprocess.check_output(['getconf','GNU_LIBC_VERSION']).decode().strip(),
    dotnetInfo=subprocess.check_output(['dotnet','--info']).decode(),root=dict(uid=root.st_uid,gid=root.st_gid,mode=oct(stat.S_IMODE(root.st_mode))),
    installationExists=Path('/opt/gagamba').exists(),inspection=result.stdout.strip(),inspectionExit=result.returncode,
    cgroupRoot=dict(uid=s.st_uid,gid=s.st_gid,mode=oct(stat.S_IMODE(s.st_mode)),writable=os.access(cgroup,os.W_OK)),
    namespaceLinks={name:Path('/proc/self/ns',name).readlink().as_posix() for name in ['pid','user','time']},
    capabilities=[line for line in Path('/proc/self/status').read_text().splitlines() if line.startswith(('CapEff:','CapPrm:'))],
    knownHelperProcessesRemaining=remaining,cleanup='Known helper processes reaped/exited; private build/candidate copies and raw evidence retained. No domain cleanup qualification.',
    scope='Read-only nonprivileged host observation, no installation or permission change')
(OUT/'host-final.json').write_text(json.dumps(facts,indent=2)+'\n');assert not remaining,remaining
print(json.dumps({k:v for k,v in facts.items() if k!='dotnetInfo'},indent=2))
