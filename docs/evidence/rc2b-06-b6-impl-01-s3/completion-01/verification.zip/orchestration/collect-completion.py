from pathlib import Path
import hashlib,json,subprocess,re,xml.etree.ElementTree as ET,zipfile
R=Path(r'C:\Users\Laszlos\source\repos\Gagamba');HERE=Path(__file__).parent
OUT=R/'artifacts/rc2b-06-b6-s3-complete';DOC=R/'docs/evidence/rc2b-06-b6-impl-01-s3/completion-01'
BASE='a88f8913fe0b7854a4779f8aad7dc55b79fe6b18';SOURCE='0eb7a7174efb04237a7d69732a6589d1e945125c'
def git(*a):return subprocess.check_output(['git','-C',str(R),*a])
def line(*a):return git(*a).decode().strip()
def sha(data):return hashlib.sha256(data).hexdigest()
def write(name,obj):(DOC/name).write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8',newline='\n')
assert line('rev-parse','HEAD')==SOURCE and line('symbolic-ref','--short','HEAD')=='main'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
assert not git('diff',BASE,SOURCE,'--','src')
old_binding=json.loads(git('cat-file','blob',BASE+':docs/evidence/rc2b-06-b6-impl-01-s3/source-binding.json'))
before=old_binding['preservedUntracked'];assert len(before)==44
for item in before:assert sha((R/item['Path']).read_bytes())==item['Sha256'],item['Path']
assert set(git('ls-files','--others','--exclude-standard','-z').decode().rstrip('\0').split('\0'))=={item['Path'] for item in before}
initial=(HERE/'worktrees-before.txt').read_text(encoding='utf-8').replace('\r\n','\n').strip().split('\n\n')
now=line('worktree','list','--porcelain').split('\n\n')
def norm(rows):
    rows=rows.copy();rows[0]='\n'.join('HEAD canonical' if s.startswith('HEAD ') else s for s in rows[0].splitlines());return rows
assert len(now)==74 and norm(initial)==norm(now)
old_commits=(HERE/'commits-before.txt').read_text(encoding='utf-8').splitlines();assert len(old_commits)==18
for row in old_commits:git('merge-base','--is-ancestor',row.split()[0],SOURCE)
paths=line('diff','--name-only',BASE,SOURCE).splitlines();assert len(paths)==12 and all(p.startswith(('tests/','eng/qualify-s3-')) for p in paths)
files=[dict(path=p,gitBlob=line('rev-parse',SOURCE+':'+p),sha256=sha(git('cat-file','blob',SOURCE+':'+p))) for p in paths]
doc_paths=['docs/PROJECT-STATUS.md','docs/handoff.md','docs/work-queue.md','docs/evidence/rc2b-06-b6-impl-01-s3.md']+[
    'docs/evidence/rc2b-06-b6-impl-01-s3/completion-01/'+n for n in ['pre-code-reconciliation.md','source-binding.json','binary-inventory.json','case-outcomes.json','verification.zip']]
preserved={}
for path in ['docs/evidence/rc2b-06-b6-impl-01-s3.md','docs/evidence/rc2b-06-b6-impl-01-s3/source-binding.json',
    'docs/evidence/rc2b-06-b6-impl-01-s3/source-map.json','docs/evidence/rc2b-06-b6-impl-01-s3/golden-wire-vectors.json','docs/evidence/rc2b-06-b6-impl-01-s3/verification.zip']:
    data=git('cat-file','blob',BASE+':'+path);preserved[path]=sha(data)
    assert git('cat-file','blob',SOURCE+':'+path)==data
assert preserved['docs/evidence/rc2b-06-b6-impl-01-s3/verification.zip']=='4a3e29ceaa2821f4cbbd3974b6a505b9c4370241737e6979145c004496770bc5'
governing=old_binding['governingCommittedSha256']
for path,digest in governing.items():assert sha(git('cat-file','blob',SOURCE+':'+path))==digest
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def trx(path):
    root=ET.parse(path).getroot();c=root.find('t:ResultSummary/t:Counters',ns).attrib
    definitions={n.attrib['id']:n.find('t:TestMethod',ns).attrib.get('className','') for n in root.findall('t:TestDefinitions/t:UnitTest',ns)}
    classes={};added=[]
    for result in root.findall('t:Results/t:UnitTestResult',ns):
        name=definitions[result.attrib['testId']];outcome=result.attrib['outcome'];bucket=classes.setdefault(name,{})
        bucket[outcome]=bucket.get(outcome,0)+1
        if name.endswith(('InstallationCompletionTests','InstallationTransferNativeTests','InstallationEvidenceEdgeTests')):
            added.append(dict(className=name,testName=result.attrib['testName'],outcome=outcome))
    assert c.get('failed','0')=='0',path
    outcomes={}
    for counts in classes.values():
        for outcome,count in counts.items():outcomes[outcome]=outcomes.get(outcome,0)+count
    return dict(path=path.relative_to(R).as_posix(),sha256=sha(path.read_bytes()),source=SOURCE,counters=c,reconciledOutcomes=outcomes,classes=classes,addedTestInventory=added)
supplemental=next((OUT/'production-regressions/trx').glob('*.trx'))
receipts=[trx(p) for p in [OUT/'debug/completion-debug.trx',OUT/'release-runner/completion-release-runner.trx',supplemental,
    OUT/'native-production-final/completion-native-production.trx',OUT/'mixed-final/completion-mixed.trx',OUT/'fixture/completion-fixture.trx']]
expected=[(1188,331),(1188,331),(1157,261),(136,0),(91,0),(15,0)]
for r,(passed,skipped) in zip(receipts,expected):assert (r['reconciledOutcomes'].get('Passed',0),r['reconciledOutcomes'].get('NotExecuted',0))==(passed,skipped),(r['path'],r['reconciledOutcomes'])
assert len(receipts[0]['addedTestInventory'])==65
assert sum(c.get('Passed',0) for n,c in receipts[0]['classes'].items() if 'Wp05B5C3' in n)==61
for r in receipts[:3]:assert sum(c.get('Passed',0) for n,c in r['classes'].items() if 'Wp05B5C3' in n)==61
s1=json.loads((OUT/'s1/results.json').read_text(encoding='utf-8-sig'));assert len(s1)==51 and all(r['Passed'] for r in s1)
topology=json.loads((OUT/'topology-final/results.json').read_text());assert topology['run']==65 and topology['failures']==topology['errors']==topology['skipped']==0 and len(topology['results'])==65
assert len([r for r in topology['results'] if r['mode'].startswith('integrated-')])==15
loaded=json.loads((OUT/'loaded-final/results.json').read_text());assert loaded['passed']==8 and loaded['failed']==0
production=json.loads((OUT/'production-refusal-final/results.json').read_text());assert production['passed']==2 and production['failed']==0
host=json.loads((OUT/'host-final.json').read_text());assert host['knownHelperProcessesRemaining']==[] and not host['installationExists'] and host['root']['mode']=='0o777'
buffer=json.loads((R/'artifacts/rc2b-06-b6-s3-complete-buffer-native.log').read_text(encoding='utf-8-sig'));assert buffer['Passed']==2 and buffer['Failed']==0
assert buffer['Results'][1]['KernelFlags']&0x20 and not buffer['Results'][1]['Accepted']
legacy=json.loads((OUT/'legacy-b2-final/results.json').read_text())
report=(HERE/'completion-report.md').read_text(encoding='utf-8')
rows=[dict(case=int(n),executed=done.strip(),remaining=remaining.strip()) for n,done,remaining in re.findall(r'^\| (\d+) \| ([^|]+) \| ([^|]+) \|$',report,re.M)]
assert [r['case'] for r in rows]==list(range(1,29))
DOC.mkdir(parents=True,exist_ok=True)
(DOC/'pre-code-reconciliation.md').write_bytes((HERE/'reconciliation.md').read_bytes())
write('case-outcomes.json',dict(scope='D/PN/native mechanisms and actual production refusals, not 28 full-system qualified passes',source=SOURCE,cases=rows))
write('source-binding.json',dict(commission='GAGAMBA-RC2B-06-B6-IMPL-01-S3-COMPLETE-01',date='2026-11-04',branch='main',
    start=dict(commit=BASE,tree=line('rev-parse',BASE+'^{tree}')),source=dict(commit=SOURCE,tree=line('rev-parse',SOURCE+'^{tree}')),
    runtimeImplementationUnchangedFrom='5b2fe73567a9c33df50fc7c662436a67814a86f4',changedFiles=files,documentationPaths=doc_paths,
    precedingLocalCommitCount=18,preservedUntracked=before,preservedWorktreeCount=74,preservedCommittedSha256=preserved,governingCommittedSha256=governing,
    remoteTracking=line('rev-parse','origin/main'),sourceAheadBehind=line('rev-list','--left-right','--count','origin/main...HEAD'),
    testResults=receipts,canonicalAdded=dict(portablePassed=24,nativeSkippedOnWindows=41,total=65),linuxS3Batch=dict(portable=75,nativeComponents=61,total=136),
    s1=dict(passed=51,failed=0,skipped=0),topology=dict(passed=65,failed=0,skipped=0,isolatedB2=49,integratedMechanism=15,actualProductionOwnerRefusal=1,
        caseInventory=[dict(mode=r['mode'],directory=r['directory'],pids=r['pids'],cleanup=r['cleanup']) for r in topology['results']]),
    loadedScenarios=dict(passed=8,scope=loaded['scope']),actualProductionHelperControl=dict(passed=2),externalBufferControl=dict(passed=2),
    legacyB2=legacy,host=host,remaining='Full trusted installation/loaded-role positives and selector races Q; delegated v1/I/HELD/domain lifecycle; full native loader; unavailable alternate credentials/time namespaces and forced PID reuse. No production authority from fixtures.'))
binaries=[]
for base in [OUT/'release/bin',OUT/'production-regressions/bin/Release/net10.0']:
    for path in base.rglob('Gagamba*.dll'):
        if path.is_file():binaries.append(dict(path=path.relative_to(R).as_posix(),sha256=sha(path.read_bytes()),bytes=path.stat().st_size))
write('binary-inventory.json',dict(source=SOURCE,scope='Actual Release fixtures, helpers, core and supplemental test outputs; not an installed artifact set',artifacts=binaries,
    testLauncher=json.loads((OUT/'linux-final-source.json').read_text()),externalPeer=dict(project='artifacts/rc2b-06-b6-s3-complete/buffer-probe/BufferProbe.csproj',
        sourceSha256=sha((OUT/'buffer-probe/Program.cs').read_bytes()),dllSha256=sha((OUT/'buffer-probe/bin/Release/net10.0/Gagamba.Execution.Linux.M1.B2Controller.dll').read_bytes()))))
assert (OUT/'buffer-probe/bin/Release/net10.0/Gagamba.Execution.Linux.M1.dll').read_bytes()==(OUT/'release/bin/B2Controller/release/Gagamba.Execution.Linux.M1.dll').read_bytes()
members={}
for path in R.glob('artifacts/rc2b-06-b6-s3-complete*.log'):members[path.relative_to(R).as_posix()]=path.read_bytes()
for path in OUT.rglob('*'):
    if not path.is_file() or any(part in ('bin','obj','release','order','fresh-debug','fresh-release','solution','owner','recovery','publish') for part in path.relative_to(OUT).parts):continue
    if path.suffix in ('.trx','.log','.json','.jsonl','.txt','.cs','.csproj'):members[path.relative_to(R).as_posix()]=path.read_bytes()
for name in ['final-windows.ps1','final-linux-components.py','finish-native-production.py','host-final.py','BufferBoundaryProbe.cs','collect-completion.py','reconciliation.md','worktrees-before.txt','commits-before.txt','status-before.txt']:
    members['orchestration/'+name]=(HERE/name).read_bytes()
members['orchestration/buffer-commands.json']=(json.dumps(dict(source=SOURCE,build=['dotnet','build','artifacts/rc2b-06-b6-s3-complete/buffer-probe/BufferProbe.csproj','-c','Release','-v:q'],
    run=['dotnet','/mnt/c/Users/Laszlos/source/repos/Gagamba/artifacts/rc2b-06-b6-s3-complete/buffer-probe/bin/Release/net10.0/Gagamba.Execution.Linux.M1.B2Controller.dll']),indent=2)+'\n').encode()
members['MANIFEST.json']=(json.dumps({name:dict(sha256=sha(data),bytes=len(data)) for name,data in sorted(members.items())},indent=2)+'\n').encode()
with zipfile.ZipFile(DOC/'verification.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
archive_sha=sha((DOC/'verification.zip').read_bytes())
report=report.replace('@ARCHIVE_SHA256@',archive_sha)
for old,new in [('all44','all 44'),('all74','all 74'),('all18','all 18'),('All44','All 44'),('all20','all 20'),('All61','All 61'),('14-artifact','14-artifact'),('rebuilt14','rebuilt 14'),('source5b2fe7','source 5b2fe7'),('exact0eb7a71','exact 0eb7a71')]:report=report.replace(old,new)
old_report=git('cat-file','blob',BASE+':docs/evidence/rc2b-06-b6-impl-01-s3.md')
(R/'docs/evidence/rc2b-06-b6-impl-01-s3.md').write_bytes(report.encode()+old_report)
block='''> **S3 IMPLEMENTED WITH QUALIFICATIONS — READY FOR INDEPENDENT Q1 (2026-11-04).**
> Focused verification is committed at `0eb7a7174efb04237a7d69732a6589d1e945125c`; runtime source remains unchanged from `5b2fe73567a9c33df50fc7c662436a67814a86f4`. No demonstrated runtime defect or new authority path was introduced.
> M1 Debug/Release runner 1188/0/331 each; actual Release supplemental 1157/0/261; S1 51/51; Release-core Linux 75 portable +61 native components; topology driver 65/65, loaded-image scenarios 8/8, actual helper controls 2/2, external truncation controls 2/2, legacy B2 22/22, mixed Linux 91/91 and S2 transactions 11/11. Counts do not establish 28 full-system passes.
> Next: GAGAMBA-RC2B-06-B6-IMPL-01-S3-Q1. Trusted-root production positives/selector races/complete loaded closure and delegated native HELD/domain cases remain Pending. Root is still 0:0 0777; `/opt/gagamba` is absent and no delegated parent was provisioned. No privileged installation, activation, S4/B7 or push.
> [Completion delta, 28 outcomes and qualifications](evidence/rc2b-06-b6-impl-01-s3.md) · [Exact source, inventories and raw evidence](evidence/rc2b-06-b6-impl-01-s3/completion-01/source-binding.json)

'''
for name in ['docs/PROJECT-STATUS.md','docs/handoff.md','docs/work-queue.md']:
    old=git('cat-file','blob',BASE+':'+name).decode();first,rest=old.split('\n',1)
    (R/name).write_text(first+'\n\n'+block+rest.lstrip('\n'),encoding='utf-8',newline='\n')
print(json.dumps(dict(source=SOURCE,sourceTree=line('rev-parse',SOURCE+'^{tree}'),sourceFiles=len(files),documentationPaths=len(doc_paths),matrixRows=len(rows),archiveFiles=len(members),archiveBytes=(DOC/'verification.zip').stat().st_size,archiveSha256=archive_sha,
    preCodeSha256=sha((DOC/'pre-code-reconciliation.md').read_bytes()),sourceBindingSha256=sha((DOC/'source-binding.json').read_bytes()),evidenceWorkingSha256=sha((R/'docs/evidence/rc2b-06-b6-impl-01-s3.md').read_bytes())),indent=2))
