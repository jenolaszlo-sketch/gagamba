from pathlib import Path
import os,shutil,subprocess,hashlib,json,uuid
R=Path('/mnt/c/Users/Laszlos/source/repos/Gagamba');OUT=R/'artifacts/rc2b-06-b6-s3-complete'
source=subprocess.check_output(['git','-c','safe.directory='+str(R),'-C',str(R),'rev-parse','HEAD']).decode().strip();assert source=='0eb7a7174efb04237a7d69732a6589d1e945125c'
assert os.getuid()==1000
dest=OUT/'production-regressions/bin/Release/net10.0/Gagamba.Execution.Linux.M1.Tests'
stub=R/'tests/Gagamba.Execution.Linux.M1.Tests/bin/Debug/net10.0/Gagamba.Execution.Linux.M1.Tests'
assert stub.read_bytes()[:4]==b'\x7fELF';shutil.copyfile(stub,dest)
if not os.access(dest,os.X_OK):
    private=Path('/tmp/gagamba-s3-production-tests-'+uuid.uuid4().hex);shutil.copytree(dest.parent,private);dest=private/dest.name;dest.chmod(0o755)
fixture=OUT/'release/bin/B2Controller/release/Gagamba.Execution.Linux.M1.B2Controller.dll'
env=os.environ.copy();env.update(GAGAMBA_S3_EVIDENCE_FIXTURE=str(fixture),GAGAMBA_S3_OBSERVATIONS=str(OUT/'native-production-final/observations'))
args=['dotnet','vstest',str(dest)+'.dll',
    '--TestCaseFilter:FullyQualifiedName~InstallationCompletionTests|FullyQualifiedName~InstallationTransferNativeTests|FullyQualifiedName~InstallationEvidenceEdgeTests|FullyQualifiedName~QualifiedLauncherNativeTests|FullyQualifiedName~B2EvidenceNativeTests|FullyQualifiedName~InstallationHandshakeTests|FullyQualifiedName~InstallationWireTests|FullyQualifiedName~LoadedMappingTests',
    '--logger:trx;LogFileName=completion-native-production.trx','--ResultsDirectory:'+str(OUT/'native-production-final')]
with (OUT/'native-production-final.log').open('w') as log:
    log.write('SOURCE '+source+'\nCOMMAND '+json.dumps(args)+'\n');log.flush()
    result=subprocess.run(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
assert result.returncode==0,'native-production-final failed'
(OUT/'linux-final-source.json').write_text(json.dumps(dict(source=source,uid=os.getuid(),gid=os.getgid(),kernel=os.uname().release,
    testApphostSha256=hashlib.sha256(stub.read_bytes()).hexdigest(),testRunner=str(dest)+'.dll',
    fixtureSha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),scope='Native components and actual Release refusals, no trusted installation positive'),indent=2)+'\n')
print((OUT/'native-production-final.log').read_text()[-1200:])
