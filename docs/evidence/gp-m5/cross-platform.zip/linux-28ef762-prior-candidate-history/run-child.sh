#!/usr/bin/env bash
set -Eeuo pipefail
report=/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-28ef762
ws=/home/gaga/gp-m5-qualification-28ef762
sha=28ef762d88ff693d84e37e5747f996d3c27a0f97
sdk=/home/gaga/aaaw-m5-qualification-7833bbe/dotnet
mkdir -p "$report/test-results"
export PATH="$sdk:$PATH" DOTNET_ROOT="$sdk" DOTNET_CLI_HOME=/home/gaga
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 UseSharedCompilation=false
export MSBUILDDISABLENODEREUSE=1 DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER=1
export GAGAMBA_QUALIFICATION=1 GAGAMBA_QUALIFICATION_OUTPUT="$report/qualification.json"
export GAGAMBA_SOURCE_SHA="$sha" GAGAMBA_LINUX_CGROUP=/sys/fs/cgroup/$(basename "$GAGAMBA_LINUX_CGROUP")
export GAGAMBA_TEST_CGROUP_ROOT="$GAGAMBA_LINUX_CGROUP"
cd "$ws"
{
  echo "source_sha=$sha"
  echo "sdk=$($sdk/dotnet --version)"
  echo "identity=$(id)"
  echo "cgroup=$(cat /proc/self/cgroup)"
  echo "capture_root=$GAGAMBA_LINUX_CGROUP"
  echo "kernel=$(uname -a)"
  echo "controllers=$(cat "$GAGAMBA_LINUX_CGROUP/cgroup.controllers")"
} | tee "$report/native-inventory-start.txt"
status=0
run_test() {
  name="$1"; project="$2"
  echo "RUN $name: dotnet test $project -c Release --nologo --logger trx;LogFileName=$name.trx --results-directory $report/test-results"
  set +e
  "$sdk/dotnet" test "$project" -c Release --nologo --logger "trx;LogFileName=$name.trx" --results-directory "$report/test-results" >"$report/$name.log" 2>&1
  result=$?
  set -e
  echo "$name exit=$result"
  tail -n 30 "$report/$name.log"
  if [ "$result" -ne 0 ]; then status=1; fi
}
run_test linux-provider tests/Gagamba.Execution.Linux.Tests/Gagamba.Execution.Linux.Tests.csproj
run_test execution tests/Gagamba.Execution.Tests/Gagamba.Execution.Tests.csproj
run_test runtime tests/Gagamba.Runtime.Tests/Gagamba.Runtime.Tests.csproj
run_test conformance-strict tests/Gagamba.Conformance.Tests/Gagamba.Conformance.Tests.csproj
"$sdk/dotnet" build-server shutdown >"$report/build-server-shutdown.log" 2>&1 || status=1
{
  echo "cgroup_events=$(tr '\n' ';' < "$GAGAMBA_LINUX_CGROUP/cgroup.events")"
  find "$GAGAMBA_LINUX_CGROUP" -maxdepth 2 -type f \( -name cgroup.events -o -name cgroup.procs \) -print -exec cat {} \;
} > "$report/native-inventory-end.txt"
echo "qualification_exit=$status" | tee -a "$report/native-inventory-end.txt"
exit "$status"