set -euo pipefail
report=/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-28ef762
ws=/home/gaga/gp-m5-qualification-28ef762
test ! -e "$ws"
mkdir -p "$ws"
tar -xf "$report/source.tar" -C "$ws"
chown -R gaga:gaga "$ws"
test "$(cat "$report/source.sha")" = 28ef762d88ff693d84e37e5747f996d3c27a0f97
sha256sum "$report/source.tar"
stat -c '%U:%G %n' "$ws"
test -f "$ws/Gagamba.sln"
ls "$ws/tests"
