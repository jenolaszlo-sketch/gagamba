#!/usr/bin/env bash
set -Eeuo pipefail
report=/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-28ef762
uid=$(id -u gaga); gid=$(id -g gaga); home=$(getent passwd gaga | cut -d: -f6)
parent=/sys/fs/cgroup/gagamba-gp-m5-linux-provider-rerun-$(date +%s)
gl2=/sys/fs/cgroup/gagamba-gl2-tests
ar5=/sys/fs/cgroup/gagamba-ar5-tests
test "$(stat -fc %T /sys/fs/cgroup)" = cgroup2fs
test ! -e "$parent" && test ! -e "$gl2" && test ! -e "$ar5"
mkdir "$parent" "$parent/gl2" "$parent/ar5"
chown "$uid:$gid" "$parent" "$parent/cgroup.procs" "$parent/cgroup.subtree_control" "$parent/gl2" "$parent/ar5"
ln -s "$parent/gl2" "$gl2"
ln -s "$parent/ar5" "$ar5"
cleanup() {
  rc=$?
  rm -f "$gl2" "$ar5"
  for i in $(seq 1 100); do
    if grep -q '^populated 0$' "$parent/cgroup.events"; then break; fi
    sleep 0.2
  done
  cat "$parent/cgroup.events" | tee "$report/linux-provider-rerun-cgroup-final.txt"
  find "$parent" -mindepth 1 -maxdepth 5 -type f \( -name cgroup.events -o -name cgroup.procs \) -print -exec cat {} \; | tee -a "$report/linux-provider-rerun-cgroup-final.txt"
  if [[ -n "$(find "$parent" -type d -mindepth 1 -print)" ]]; then
    find "$parent" -depth -type d -mindepth 1 -exec rmdir {} \; 2>&1 | tee -a "$report/linux-provider-rerun-cgroup-final.txt" || rc=1
  fi
  if [[ -n "$(find "$parent" -mindepth 1 -type d -print)" ]] || ! grep -q '^populated 0$' "$parent/cgroup.events"; then
    echo "cgroup not empty; preserving: $parent" | tee -a "$report/linux-provider-rerun-cgroup-final.txt"
    rc=1
  else
    rmdir "$parent" || rc=1
    echo "parent_removed=true path=$parent" | tee -a "$report/linux-provider-rerun-cgroup-final.txt"
  fi
  exit "$rc"
}
trap cleanup EXIT
export GAGAMBA_LINUX_CGROUP="$parent" QUALIFICATION_UID="$uid" QUALIFICATION_GID="$gid" QUALIFICATION_HOME="$home"
set +e
bash -c 'echo $$ > "$GAGAMBA_LINUX_CGROUP/cgroup.procs"; exec setpriv --reuid="$QUALIFICATION_UID" --regid="$QUALIFICATION_GID" --clear-groups env HOME="$QUALIFICATION_HOME" GAGAMBA_LINUX_CGROUP="$GAGAMBA_LINUX_CGROUP" bash /mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-28ef762/run-linux-only.sh' >"$report/linux-provider-rerun-parent.log" 2>&1
status=$?
set -e
cat "$report/linux-provider-rerun-parent.log"
exit "$status"