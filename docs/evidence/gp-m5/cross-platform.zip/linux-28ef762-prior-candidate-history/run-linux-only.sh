#!/usr/bin/env bash
set -Eeuo pipefail
report=/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-28ef762
ws=/home/gaga/gp-m5-qualification-28ef762
sdk=/home/gaga/aaaw-m5-qualification-7833bbe/dotnet
mkdir -p "$report/test-results"
export PATH="$sdk:$PATH" DOTNET_ROOT="$sdk" DOTNET_CLI_HOME=/home/gaga
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 UseSharedCompilation=false
export MSBUILDDISABLENODEREUSE=1 DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER=1
export GAGAMBA_QUALIFICATION=1 GAGAMBA_TEST_CGROUP_ROOT="$GAGAMBA_LINUX_CGROUP"
cd "$ws"
echo "source_sha=28ef762d88ff693d84e37e5747f996d3c27a0f97" | tee "$report/linux-provider-rerun.log"
echo "cgroup=$(cat /proc/self/cgroup)" | tee -a "$report/linux-provider-rerun.log"
"$sdk/dotnet" test tests/Gagamba.Execution.Linux.Tests/Gagamba.Execution.Linux.Tests.csproj -c Release --no-restore --nologo --logger "trx;LogFileName=linux-provider-delegated.trx" --results-directory "$report/test-results" >>"$report/linux-provider-rerun.log" 2>&1
status=$?
tail -n 40 "$report/linux-provider-rerun.log"
exit "$status"