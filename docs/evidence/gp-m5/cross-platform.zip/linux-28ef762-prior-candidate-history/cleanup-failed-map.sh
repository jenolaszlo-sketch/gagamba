set -euo pipefail
p=/sys/fs/cgroup/gagamba-gp-m5-linux-provider-rerun-1792104086
cat "$p/cgroup.events"
find "$p" -mindepth 1 -type d -exec sh -c 'cat "$1/cgroup.events"; test "$(awk "$1 == \"populated\" {print $2}" "$1/cgroup.events")" = 0' _ {} \;
for d in $(find "$p" -depth -mindepth 1 -type d); do rmdir "$d"; done
rmdir "$p"
test ! -e /sys/fs/cgroup/gagamba-gl2-tests
test ! -e /sys/fs/cgroup/gagamba-ar5-tests
echo cleanup_completed=true