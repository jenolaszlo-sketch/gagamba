#!/usr/bin/env bash
set -Eeuo pipefail
report=/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-0c1f05e
ws=/home/gaga/gp-m5-qualification-0c1f05e
sdk=/home/gaga/aaaw-m5-qualification-7833bbe/dotnet
uid=$(id -u gaga); gid=$(id -g gaga); home=$(getent passwd gaga | cut -d: -f6)
parent=/sys/fs/cgroup/gagamba-ar5-tests
test "$(stat -fc %T /sys/fs/cgroup)" = cgroup2fs
test ! -e "$parent"
mkdir "$parent"
chown "$uid:$gid" "$parent" "$parent/cgroup.procs" "$parent/cgroup.subtree_control"
cleanup() {
  rc=$?
  for i in $(seq 1 100); do
    if grep -q '^populated 0$' "$parent/cgroup.events"; then break; fi
    sleep 0.2
  done
  cat "$parent/cgroup.events" | tee "$report/ar5-attempt2-cgroup-final.txt"
  find "$parent" -mindepth 1 -maxdepth 5 -type f \( -name cgroup.events -o -name cgroup.procs \) -print -exec cat {} \; | tee -a "$report/ar5-attempt2-cgroup-final.txt"
  if [[ -n "$(find "$parent" -mindepth 1 -type d -print)" ]] || ! grep -q '^populated 0$' "$parent/cgroup.events"; then
    echo "AR5 cgroup not empty; preserving for diagnosis: $parent" | tee -a "$report/ar5-attempt2-cgroup-final.txt"
    rc=1
  else
    rmdir "$parent" || rc=1
    echo "parent_removed=true path=$parent" | tee -a "$report/ar5-attempt2-cgroup-final.txt"
  fi
  exit "$rc"
}
trap cleanup EXIT
export AR5_CGROUP="$parent" QUALIFICATION_UID="$uid" QUALIFICATION_GID="$gid" QUALIFICATION_HOME="$home"
set +e
bash -c 'echo $$ > "$AR5_CGROUP/cgroup.procs"; exec setpriv --reuid="$QUALIFICATION_UID" --regid="$QUALIFICATION_GID" --clear-groups env HOME="$QUALIFICATION_HOME" AR5_CGROUP="$AR5_CGROUP" QUALIFICATION_REPORT="/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-0c1f05e" bash /mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-0c1f05e/run-ar5-child.sh' >"$report/ar5-attempt2-parent.log" 2>&1
status=$?
set -e
cat "$report/ar5-attempt2-parent.log"
exit "$status"