set -euo pipefail
report=/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-0c1f05e
ws=/home/gaga/gp-m5-qualification-0c1f05e
test ! -e "$ws"
mkdir -p "$ws"
tar -xf "$report/source.tar" -C "$ws"
chown -R gaga:gaga "$ws"
test "$(cat "$report/source.sha")" = 0c1f05e199588622a5987f95a9149374f5bd858b
sha256sum "$report/source.tar"
stat -c '%U:%G %n' "$ws"
test -f "$ws/Gagamba.sln"