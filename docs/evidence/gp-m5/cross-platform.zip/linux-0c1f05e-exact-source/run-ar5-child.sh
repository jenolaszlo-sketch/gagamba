#!/usr/bin/env bash
set -Eeuo pipefail
report="$QUALIFICATION_REPORT"
ws=/home/gaga/gp-m5-qualification-0c1f05e
sdk=/home/gaga/aaaw-m5-qualification-7833bbe/dotnet
export PATH="$sdk:$PATH" DOTNET_ROOT="$sdk" DOTNET_CLI_HOME=/home/gaga
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 UseSharedCompilation=false
export MSBUILDDISABLENODEREUSE=1 DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER=1 GAGAMBA_QUALIFICATION=1
cd "$ws"
echo "source_sha=0c1f05e199588622a5987f95a9149374f5bd858b"
echo "cgroup=$(cat /proc/self/cgroup)"
set +e
"$sdk/dotnet" test tests/Gagamba.Execution.Linux.Tests/Gagamba.Execution.Linux.Tests.csproj -c Release --no-build --no-restore --nologo --filter "FullyQualifiedName~NativeCaptureConcurrentOutputAndOverflow|FullyQualifiedName~DeadlineStopsDescendantHeldPipes" --logger "trx;LogFileName=ar5-native-capture-deadline-attempt2.trx" --results-directory "$report/test-results" > "$report/ar5-native-capture-deadline-attempt2.log" 2>&1
status=$?
set -e
tail -n 35 "$report/ar5-native-capture-deadline-attempt2.log"
exit "$status"