#!/usr/bin/env bash
set -Eeuo pipefail
report=/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-0c1f05e
ws=/home/gaga/gp-m5-qualification-0c1f05e
sdk=/home/gaga/aaaw-m5-qualification-7833bbe/dotnet
export PATH="$sdk:$PATH" DOTNET_ROOT="$sdk" DOTNET_CLI_HOME=/home/gaga HOME=/home/gaga
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 UseSharedCompilation=false
export MSBUILDDISABLENODEREUSE=1 DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER=1
export GAGAMBA_LINUX_CGROUP="$GAGAMBA_LINUX_CGROUP" GAGAMBA_QUALIFICATION=1
cd "$ws"
echo "source_sha=0c1f05e199588622a5987f95a9149374f5bd858b"
echo "sdk=$($sdk/dotnet --version)"
echo "cgroup=$(cat /proc/self/cgroup)"
echo "candidate=$ws/canonical-feed"
set +e
python3 eng/verify_package_consumer.py --packages-dir canonical-feed --version 0.1.0-preview.4-gp-m5.1 --source-sha 0c1f05e199588622a5987f95a9149374f5bd858b --output "$report/consumer-linux.json" > "$report/consumer-linux.log" 2>&1
status=$?
set -e
cat "$report/consumer-linux.log"
exit "$status"