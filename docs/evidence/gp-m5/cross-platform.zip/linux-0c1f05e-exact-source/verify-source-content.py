#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, tarfile
from pathlib import Path

archive = Path('/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-0c1f05e/source.tar')
workspace = Path('/home/gaga/gp-m5-qualification-0c1f05e')
report = Path('/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-0c1f05e/source-content-verification.json')
source_sha = '0c1f05e199588622a5987f95a9149374f5bd858b'
archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
regular = symlinks = mismatches = 0
mismatch_examples = []
with tarfile.open(archive, 'r:') as tf:
    for member in tf.getmembers():
        rel = Path(member.name)
        if rel.is_absolute() or '..' in rel.parts:
            mismatches += 1
            mismatch_examples.append({'path': member.name, 'reason': 'unsafe archive path'})
            continue
        local = workspace / rel
        try:
            st = local.lstat()
        except FileNotFoundError:
            mismatches += 1
            mismatch_examples.append({'path': member.name, 'reason': 'missing from native workspace'})
            continue
        if member.isfile():
            regular += 1
            if not local.is_file() or local.is_symlink():
                ok = False
            else:
                archived = tf.extractfile(member).read()
                local_hash = hashlib.sha256(local.read_bytes()).hexdigest()
                archive_file_hash = hashlib.sha256(archived).hexdigest()
                ok = local_hash == archive_file_hash
            if not ok:
                mismatches += 1
                mismatch_examples.append({'path': member.name, 'reason': 'regular-file bytes differ'})
        elif member.issym():
            symlinks += 1
            ok = local.is_symlink() and os.readlink(local) == member.linkname
            if not ok:
                mismatches += 1
                mismatch_examples.append({'path': member.name, 'reason': 'symlink target differs'})
        elif member.isdir():
            if not local.is_dir():
                mismatches += 1
                mismatch_examples.append({'path': member.name, 'reason': 'directory missing or wrong type'})
        else:
            mismatches += 1
            mismatch_examples.append({'path': member.name, 'reason': 'unsupported archive member type'})

payload = {
    'schema': 'gagamba-source-content-verification/v1',
    'sourceSha': source_sha,
    'sourceIdentity': 'git archive of exact commit; native workspace has no .git metadata; this is not a native git-clean claim',
    'archiveSha256': archive_hash,
    'regularFilesCompared': regular,
    'symlinksCompared': symlinks,
    'mismatchCount': mismatches,
    'mismatchExamples': mismatch_examples[:20],
    'result': 'Passed' if mismatches == 0 and archive_hash == 'b969a00faa873778aadc92403199922db6a8810ccfe3f4ecf26a1eab8f7af1b3' else 'Failed',
}
report.write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
print(json.dumps(payload, indent=2))
raise SystemExit(0 if payload['result'] == 'Passed' else 1)