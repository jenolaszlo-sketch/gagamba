set -euo pipefail
report=/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-0c1f05e
source=/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/native-0c1f05e/gp-m5-native-0c1f05e199588622a5987f95a9149374f5bd858b/packages
candidate=/home/gaga/gp-m5-qualification-0c1f05e/canonical-feed
mkdir "$candidate"
find "$source" -maxdepth 1 -type f -name '*.nupkg' -exec cp {} "$candidate/" \;
chown -R gaga:gaga "$candidate"
test "$(find "$candidate" -maxdepth 1 -name '*.nupkg' | wc -l)" -eq 5
sha256sum "$candidate"/*.nupkg | tee "$report/package-sha256.txt"