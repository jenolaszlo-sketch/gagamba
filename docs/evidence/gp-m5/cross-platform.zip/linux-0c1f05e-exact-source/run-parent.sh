#!/usr/bin/env bash
set -Eeuo pipefail
report=/mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-0c1f05e
uid=$(id -u gaga); gid=$(id -g gaga); home=$(getent passwd gaga | cut -d: -f6)
parent=/sys/fs/cgroup/gagamba-gp-m5-qualification-0c1f05e-$(date +%s)
log="$report/delegated-parent.log"
test "$(stat -fc %T /sys/fs/cgroup)" = cgroup2fs
test ! -e "$parent"
mkdir "$parent"
cleanup() {
  rc=$?
  for i in $(seq 1 100); do
    if grep -q '^populated 0$' "$parent/cgroup.events"; then break; fi
    sleep 0.2
  done
  cat "$parent/cgroup.events" | tee "$report/delegated-cgroup-final.txt"
  find "$parent" -mindepth 1 -maxdepth 2 -type f \( -name cgroup.events -o -name cgroup.procs \) -print -exec cat {} \; | tee -a "$report/delegated-cgroup-final.txt"
  if [[ -n "$(find "$parent" -mindepth 1 -maxdepth 1 -type d -print)" ]] || ! grep -q '^populated 0$' "$parent/cgroup.events"; then
    echo "cgroup not empty; preserving for diagnosis: $parent" | tee -a "$report/delegated-cgroup-final.txt"
    rc=1
  else
    rmdir "$parent" || rc=1
    echo "parent_removed=true path=$parent" | tee -a "$report/delegated-cgroup-final.txt"
  fi
  exit "$rc"
}
trap cleanup EXIT
chown "$uid:$gid" "$parent" "$parent/cgroup.procs" "$parent/cgroup.subtree_control"
export GAGAMBA_LINUX_CGROUP="$parent" GAGAMBA_WORKSPACE=/home/gaga/gp-m5-qualification-0c1f05e
export GAGAMBA_SOURCE_SHA=0c1f05e199588622a5987f95a9149374f5bd858b
export GAGAMBA_QUALIFICATION=1 QUALIFICATION_HOME="$home" QUALIFICATION_UID="$uid" QUALIFICATION_GID="$gid"
set +e
bash -c 'echo $$ > "$GAGAMBA_LINUX_CGROUP/cgroup.procs"; exec setpriv --reuid="$QUALIFICATION_UID" --regid="$QUALIFICATION_GID" --clear-groups env HOME="$QUALIFICATION_HOME" bash /mnt/c/Users/Laszlos/source/repos/Solo/gp-m5/gagamba/artifacts/gp-m5/linux-regression-0c1f05e/run-child.sh' >"$log" 2>&1
status=$?
set -e
cat "$log"
exit "$status"