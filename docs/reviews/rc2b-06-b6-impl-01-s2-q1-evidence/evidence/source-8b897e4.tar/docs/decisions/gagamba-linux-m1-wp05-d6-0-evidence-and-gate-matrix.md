# WP05 D6.0 Evidence and Gate Matrix

Status: **PROPOSED - NOT APPROVED**

Binding: R12 `38f6981...`, tree `6854675d...`; D5 preservation
`578b208...`; original required changes blob `73eb09af...`.
This matrix is analysis only. No gate is accepted.

| Decision | Original finding | R12 source symbols | D2/D4/D5 evidence | Recommended contract | Missing evidence / future change | Gate blocked |
|---|---|---|---|---|---|---|
| C1 R09 | Ambiguous seal failure can leave both slots holding Intent while arbiter reports definite `NotCommitted` and requests no stop. | `ReleaseArbiter.RequestRelease` `:110-114`; `OwnershipJournal.Write` `:424-489`; `RequestStop` `:226-296`; `ReleaseRecoveryClassifier` `:28-38` | D2 ambiguous/definite probes; D4-6 fresh-process; independently reproduced | Explicit ambiguous-persistence decision; `MayHaveExecuted`; no FD4; bounded runtime stop; best-effort durable stop; retained result; recovery Intent | Decision approval; production API/arbiter change; post-change wedge/stop tests; owner domain-stop integration WP08/WP10 | G3-A11, G3-B08 |
| C2 R08 | Stop-first does not invalidate the capability; failed durable stop + second arbiter can release. | `ReleaseArbiter.RequestStop` `:226-296`; `_stopAccepted` `:24,55-61`; `PreparedTransaction.IsLive/TryConsume`; `OwnershipTransitions.TryPlanStop` `:108-150` | D2 stop-first/failed-stop; D5-CR3/CR3b diagnostics; independently reproduced | Consume/invalidate at runtime stop acceptance for normal, clock-unavailable and overflow paths; irreversible; no schema change | Decision approval; production `RequestStop` change; tests asserting `IsLive == false`; post-change fresh-lease/stop suite | G3-A02, G3-A07 |
| C3 R27 | Persisted stop deadline is immutable but `Reconciler` uses caller allowance and never consumes the deadline. | `Reconciler._stopAllowance` `:124-129`; `StopAndAwaitEmpty` call `:231`; `StopRecord` `OwnershipRecord.cs:119-122`; allowance `:202`; planner `OwnershipTransitions.cs:108-150` | D2 R27 probe; D4/D5 diagnostics; independent review agrees source gap | `Reconciler` derives remaining = deadline - verified monotonic now; expired => zero-wait urgent stop; zero/unverifiable => quarantine/Unknown; no reset | Decision approval; `Reconciler` change and deterministic clock tests; no schema change | G3-A10, R27 |
| C4 R02/R06 | Sequential duplicates get Duplicate; concurrent loser may get Refused while winner releases; retention asymmetry. | `ReleaseArbiter.RequestRelease` `:48-61,81-115,176-223`; `HeldExecution.TryWriteRelease`; `OwnershipTransitions.TryPlanReleaseIntent` | D2 concurrent probe; D4-9; D5-CR3 second-owner/fence; independently reproduced | Explicit concurrent-refusal semantics; sequential Duplicate; document outside-gate vs gate retention; no waiting; one physical write | Decision approval; possible decision-comment/retention changes; tests for all failure classes; no schema change | G3-A05 |

## Source-to-evidence sufficiency

- C1: source confirmed; D2/D4 reproduced; no production owner domain-stop
  path. Decision and post-change tests required.
- C2: source confirmed; D2/D4 reproduced; no normal single-owner release after
  stop was demonstrated. Multi-instance risk is bounded; capability contract
  is the proposed closure.
- C3: source confirmed; D2/D4 diagnostic; no production caller currently
  consumes the deadline. Decision and deterministic clock tests required.
- C4: source confirmed; D2/D4/D5 reproduced the API/retention shape; no
  second-write hazard observed. Decision and updated contract tests required.

## Gate state

No G3-A/B/C/D/E, G2a/G2b/G3 or WP05 release gate is accepted. D4/D5 fixture
passes do not convert these gates to PASS. All C1-C4 items remain unresolved
until human approval and separately authorized remediation.

## Qualification transfer

R12 evidence remains valid for R12 only. New production commits would require
new source binding and reruns:
- D1-D3 contract diagnostics;
- D4 fresh-process supervisor/crash/no-resend, with new source/tests;
- D5 native FD5 and release-path rows, with new production tree where affected;
- affected native/protocol regressions and focused suites;
- new independent review and evidence preservation.

Native FD5 semantics are not changed by C1-C4 proposals, but the tests must be
rerun and rebind if `ReleaseArbiter`/`Reconciler` production changes alter the
tree or fixtures.

## Handoff H1-H5

H1 D5-O05: component `ReleaseObservationBuffer` has zero production callers;
no production status wiring or target-status persistence claim. Future owner:
WP08/WP10 per authoritative plan.
H2: extra inherited FD5 writer/wrong-FD/helper-writer experiments remain
unclaimed; smallest safe future test-only package is a second-writer/EOF case
with documented ownership.
H3: raw wait4/pidfd termination witness remains optional; bounded control-based
standard adopted; do not reopen frozen harness.
H4: C1-C4 this package.
H5: D5 plan commit-order documentation note; no historical rewrite.

WP08/WP10, production post-release status and full G3 remain deferred.

## D6.1 amendment reconciliation additions

Status: **PROPOSED - NOT APPROVED**

| Amendment | Where addressed | Planned proof |
|---|---|---|
| A-C1-1 | C1 §D6.1 lock-safe sequence | `AmbiguousReleaseStopLockOrderProbe`; no inversion/second FD4 |
| A-C1-2 | C1 §D6.1 vocabulary; C4 §D6.1 taxonomy | `ReleaseDecisionKind.AmbiguousPersistence` retained; consumer inventory |
| A-C1-3 | C1 §D6.1 capability window | C2 prerequisite; wedge/death recovery; no resend |
| A-C2-1 | C2 §D6.1 consumption | normal/clock/overflow `IsLive == false`; duplicate no re-consume |
| A-C2-2 | C2 §D6.1 release-first | Consumed/`ReleaseAlreadyCommitted`/history checks |
| A-C2-3 | C2 §D6.1 CE-03 declaration | two-arbiter shared capability refused |
| A-C3-1 | C3 §D6.1 clock epoch | QPC compatibility; incompatible clock rejected; same/cross-boot |
| A-C3-2 | C3 §D6.1 outcome mapping | Failed vs Unknown aggregation matrix |
| A-C3-3 | C3 §D6.1 no-record path | `RuntimeAcceptedStopWithoutDurableRecordAfterRestart` |
| A-C3-4 | C3 §D6.1 Option B | already-empty kill/no-unnecessary-WAIT |
| C3 policy | C3 §D6.1; human approval sheet | Policy A recommended, PENDING HUMAN |
| A-C4-1 | C4 §D6.1 reason table | per-class refusal retention/taxonomy tests |
| A-PKG-1 | main §D6.1; C1-C4 | branch/commit/blob binding check |
| A-PKG-2 | main §D6.1; remediation | zero production callers; component-only |
| A-PKG-3 | C1 §D6.1; this matrix | `AmbiguousWedgeThenClockUnavailableStop` |
| A-PKG-4 | existing matrix declaration | no change; satisfied |

Composed acceptance case `AmbiguousWedgeThenClockUnavailableStop` must verify
ambiguous seal failure, no FD4/false NotCommitted, runtime stop requested,
clock unavailable, C2 consumption, no fabricated StopRecord, retained
ambiguity, owner death/conservative recovery and no resend.

No gate status changes. C1 -> G3-A11/G3-B08, C2 -> G3-A02/A07, C3 ->
G3-A10/R27, C4 -> G3-A05 remain diagnostic/blocked until human approvals and
new qualification on a new production tree. C1-C4 remain unapproved;
component-level evidence is not integrated qualification.

## D6.2 amendment reconciliation additions

Status: **PROPOSED - NOT APPROVED**
Design status: **DESIGN TEXT ADDRESSED - AWAITING INDEPENDENT REVIEW**

These are future test specifications, not executed D6.2 tests. No gate status
changes: every gate remains diagnostic/blocked; no production, test, native or
fixture change is authorized.

| Amendment | Contract | Revised design section | Required future proof | Gate status |
|---|---|---|---|---|
| D6.1-R1 | C3 | C3 §D6.2 R1 typed stop outcome, mapping, JournalFinalization aggregation | R1-T1..T12: typed kill failure; attempted/populated; kill unknown; population unavailable; empty; stop-progress persistence failure; final persistence failure after confirmed empty; genuine operation failure; invalid authority; identity mismatch; mixed components; repeated uncertain finalization | G3-A10/R27 remains blocked |
| D6.1-R2 | C3 | C3 §D6.2 R2 trusted clock, epoch/frequency, failure, tests | R2-A..F: compatible epoch; incompatible relative epoch; false enum-only provenance; cross-boot refusal; invalid conversion/overflow/unavailable; repeated no-reset | G3-A10/R27 remains blocked; C3 policy pending |
| D6.1-R3 | C1 (C2/C4 cross-reference) | C1 §D6.2 R3 decision order, stop-won classification, barrier tests | R3-T1..T8: ambiguity-first; stop-first; already-retained; opposing committed writer; clock-unavailable collision; durable-stop persistence failure; repeated release; owner death; capability closure; no second FD4; conservative recovery | G3-A11/G3-B08 remains blocked |
| D6.1-R4 | C1/evidence inventory | C1 §D6.2 R4 fixture provenance; this matrix | Exact fixture branch/commit/file/blob/digest and R12-vs-fixture source comparison; no copied fixture; no false ancestry | All gates unchanged |

### R1 required test row names

- Typed kill failure.
- Kill attempted but domain populated.
- Kill dispatch unknown.
- Population observation unavailable.
- Domain confirmed empty.
- Stop progress persistence failure.
- Final journal persistence failure after confirmed empty cleanup.
- Genuine reconciliation operation failure.
- Invalid cleanup authority.
- Identity mismatch.
- Mixed component outcomes.
- Aggregate result discrimination and repeated uncertain finalization.

### R2 required test row names

- Compatible production epoch and exact remaining allowance.
- Explicit incompatible construction-relative epoch rejected before subtraction.
- False enum-only `Qpc` provenance / sealed production clock invariant.
- Cross-boot refusal.
- Invalid conversion, frequency mismatch, overflow, nonpositive/unavailable.
- Repeated reconciliation/new process/partial cleanup without deadline reset.

### R3 required test row names

- Ambiguity-first retention.
- Stop-first retention.
- Already-retained decision.
- Concurrent opposing-order committed writer.
- Capability closure (C2 consumption).
- No second FD4 and no second Intent.
- Conservative recovery after ambiguity/owner death.
- Clock-unavailable and durable-stop persistence collision cases.

### R4 required binding proof

- Exact fixture branch, full commit SHA, file path, blob and SHA-256.
- `src` tree identity equal to R12 and no `native` diff.
- Evidence `SHA256SUMS`/`source-head.txt` binding.
- Explicit separation of R12 production consumers from test-only fixture
  assets; no fixture copy or merge.

C3 policy remains `C3 ZERO-WAIT POLICY - PENDING HUMAN`. C1/C3 remain subject
to focused independent review and human decisions; C2/C4 remain supported for
human decision, not approved. No test has been run by D6.2.
